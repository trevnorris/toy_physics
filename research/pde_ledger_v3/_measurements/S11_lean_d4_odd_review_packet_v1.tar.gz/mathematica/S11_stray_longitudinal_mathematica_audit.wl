$HistoryLength = 0;
ClearAll["Global`*"];
$HistoryLength = 0;
$Messages = {OutputStream["stderr", 2]};

tokenProvedTrue = "PROVED_TRUE";
tokenProvedFalse = "PROVED_FALSE";
tokenUndecided = "UNDECIDED";
tokenAdmissible = "ADMISSIBLE";
tokenExcluded = "EXCLUDED";
tokenPositive = "POSITIVE";
tokenNegative = "NEGATIVE";
tokenZero = "ZERO";
tokenNotApplicable = "NOT_APPLICABLE";
tokenUndefinedRatio = "UNDEFINED_RATIO";
tokenNotPurePower = "NOT_A_PURE_POWER";
tokenOverDetermined = "OVER_DETERMINED";
tokenExactlyDetermined = "EXACTLY_DETERMINED";
tokenUnderDetermined = "UNDER_DETERMINED";
tokenConstant = "CONSTANT";
tokenVaries = "VARIES";
tokenCompleteCoverage = "COMPLETE_COVERAGE";
tokenIncompleteCoverage = "INCOMPLETE_COVERAGE";
tokenRankDrop = "RANK_DROP";
tokenStackedDrop = "STACKED_DROP";
tokenRootCoincidence = "ROOT_COINCIDENCE";

(* Attempt 1 budget: preserve the existing exact QE primitive for up to 30 s. *)
qePrimaryBudgetSeconds = 30;
(* Attempt 2 budget: exact-rational specialization/instance decision for up to 30 s. *)
qeExactRationalBudgetSeconds = 30;

(* Every bounded CAS attempt may allocate at most 128 MiB.  This is deliberately
   well below the external guard's 1 GiB available-memory floor, so an individual
   attempt expires inside the kernel while there is still room to run its fallback. *)
casAttemptMemoryBudgetBytes = 134217728;
(* FullSimplify keeps its committed presentation for ordinary cells, but a single
   simplification may not hold the cell silent for more than 45 s. *)
simplifyPrimaryBudgetSeconds = 45;
(* A radical/Abs presentation gets the same 45 s ceiling before exact algebraic
   presentation fallbacks.  This total structural rule is applied at every helper
   call and is independent of package, dimension, root, stratum and tag. *)
algebraicPrimaryBudgetSeconds = 45;
(* The exact presentation fallback gets 15 s before the lossless identity route. *)
simplifyFallbackBudgetSeconds = 15;
(* MatrixRank and NullSpace retain their assumption-aware primary for 45 s; their
   exact-specialization/pivot fallbacks each receive a separate 45 s budget. *)
linearAlgebraPrimaryBudgetSeconds = 45;
linearAlgebraFallbackBudgetSeconds = 45;
(* Radical-bearing rank/null-space primaries receive 45 s because they can prove
   lower component ranks that the generic specialization fallback must not guess. *)
linearAlgebraRadicalPrimaryBudgetSeconds = 45;
(* Solve keeps the native call for 30 s and then gives the exact factor-lattice
   decomposition its own 30 s. *)
solvePrimaryBudgetSeconds = 30;
solveFallbackBudgetSeconds = 30;
(* Maximal-minor construction keeps Factor[Det[...]] for 30 s and then computes
   the same determinants without the optional factor presentation for 30 s. *)
minorPrimaryBudgetSeconds = 30;
minorFallbackBudgetSeconds = 30;

boundedCASAttempt[held_HoldComplete, attemptName_String,
    budgetSeconds_Integer] := Module[{memoryFailure, timeFailure},
  memoryFailure = Failure["CASMemoryBudgetExpired", <|
    "RESOURCE" -> "MEMORY",
    "ATTEMPT" -> attemptName,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> held|>];
  timeFailure = Failure["CASTimeBudgetExpired", <|
    "RESOURCE" -> "TIME",
    "ATTEMPT" -> attemptName,
    "BUDGET_SECONDS" -> budgetSeconds,
    "OPERAND" -> held|>];
  TimeConstrained[
    MemoryConstrained[Quiet[ReleaseHold[held]],
      casAttemptMemoryBudgetBytes, memoryFailure],
    budgetSeconds, timeFailure]
];

resourceFailureQ[outcome_] := MatchQ[Unevaluated[outcome],
  Failure["CASMemoryBudgetExpired" | "CASTimeBudgetExpired", _Association] |
  Failure["QEMemoryBudgetExpired" | "QEBudgetExpired", _Association]];

SetAttributes[computedOrOpaqueFailure, HoldRest];
computedOrOpaqueFailure[object_, dependentComputation_] :=
  If[FailureQ[object], object, dependentComputation];

algebraicPresentationQ[expression_] := ! FreeQ[Unevaluated[expression],
  _Abs | Power[_, exponent_Rational /; Denominator[exponent] > 1]];

primaryBudgetFor[operand_, standardBudget_Integer] :=
  If[algebraicPresentationQ[operand],
    Min[algebraicPrimaryBudgetSeconds, standardBudget], standardBudget];

linearAlgebraBudgetFor[operand_] := If[algebraicPresentationQ[operand],
  linearAlgebraRadicalPrimaryBudgetSeconds,
  linearAlgebraPrimaryBudgetSeconds];

(* Internal emission keys are mapped to the shared §8 names only here. *)
cellEmission[package_String, dimension_Integer, quantity_String] :=
  HoldComplete[CellObject, package, dimension, quantity];
localCellEmission[package_String, dimension_Integer, quantity_String] :=
  HoldComplete[LocalCellObject, package, dimension, quantity];
runEmission[quantity_String] := HoldComplete[RunObject, quantity];
localInventoryEmission[] := HoldComplete[LocalInventoryObject];

standardEmissionName[HoldComplete[CellObject, package_String, dimension_Integer,
    quantity_String]] := "WL_S11_" <> package <> "_D" <> ToString[dimension] <>
  "_" <> quantity;
standardEmissionName[HoldComplete[LocalCellObject, package_String,
    dimension_Integer, quantity_String]] := "WL_S11_LOCAL_" <> package <> "_D" <>
  ToString[dimension] <> "_" <> quantity;
standardEmissionName[HoldComplete[RunObject, quantity_String]] :=
  "WL_S11_" <> quantity;
standardEmissionName[HoldComplete[LocalInventoryObject]] :=
  "WL_S11_LOCAL_TAG_NAMES";

emittedNames = <||>;
localNames = {};
emit[internalTag_, payload_] := Module[{emittedName, rendered, stream},
  emittedName = standardEmissionName[internalTag];
  If[! StringQ[emittedName], Quit[90]];
  If[KeyExistsQ[emittedNames, emittedName], Quit[91]];
  AssociateTo[emittedNames, emittedName -> True];
  If[StringStartsQ[emittedName, "WL_S11_LOCAL_"],
    AppendTo[localNames, emittedName]];
  rendered = ToString[payload, InputForm, PageWidth -> Infinity];
  stream = First[$Output];
  WriteString[stream, emittedName <> ": " <> rendered <> "\n"];
  Flush[stream];
];

emitCell[package_, dimension_, quantity_, payload_] :=
  emit[cellEmission[package, dimension, quantity], payload];
emitLocalCell[package_, dimension_, quantity_, payload_] :=
  emit[localCellEmission[package, dimension, quantity], payload];

boundedSimplifyRoute[expression_, assumptions_, unrestricted_] := Module[
  {primaryHeld, primaryOutcome, fallbackName, fallbackHeld, fallbackOutcome,
   attempts, primaryBudget},
  primaryHeld = If[TrueQ[unrestricted],
    With[{heldExpression = expression},
      HoldComplete[FullSimplify[heldExpression]]],
    With[{heldExpression = expression, heldAssumptions = assumptions},
      HoldComplete[FullSimplify[heldExpression,
        Assumptions -> heldAssumptions]]]];
  primaryBudget = primaryBudgetFor[expression, simplifyPrimaryBudgetSeconds];
  primaryOutcome = boundedCASAttempt[primaryHeld, "PRIMARY_FULL_SIMPLIFY",
    primaryBudget];
  attempts = {<|"ATTEMPT" -> "PRIMARY_FULL_SIMPLIFY",
    "BUDGET_SECONDS" -> primaryBudget,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> primaryHeld, "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];

  If[algebraicPresentationQ[expression],
    fallbackName = "EXACT_TOGETHER_PRESENTATION";
    fallbackHeld = With[{heldExpression = expression},
      HoldComplete[Together[heldExpression]]],
    fallbackName = "BOUNDED_SIMPLIFY";
    fallbackHeld = If[TrueQ[unrestricted],
      With[{heldExpression = expression}, HoldComplete[Simplify[heldExpression]]],
      With[{heldExpression = expression, heldAssumptions = assumptions},
        HoldComplete[Simplify[heldExpression,
          Assumptions -> heldAssumptions]]]]
  ];
  fallbackOutcome = boundedCASAttempt[fallbackHeld, fallbackName,
    simplifyFallbackBudgetSeconds];
  AppendTo[attempts, <|"ATTEMPT" -> fallbackName,
    "BUDGET_SECONDS" -> simplifyFallbackBudgetSeconds,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> fallbackHeld, "OUTCOME" -> fallbackOutcome|>];
  If[! resourceFailureQ[fallbackOutcome],
    Return[<|"OUTCOME" -> fallbackOutcome, "ATTEMPTS" -> attempts|>]];

  (* Identity is an exact, lossless presentation fallback, not a claim that the
     operand simplified.  It keeps downstream physical objects computable. *)
  AppendTo[attempts, <|"ATTEMPT" -> "EXACT_IDENTITY_PRESENTATION",
    "OPERAND" -> HoldComplete[Identity[expression]],
    "OUTCOME" -> Identity[expression]|>];
  <|"OUTCOME" -> Identity[expression], "ATTEMPTS" -> attempts|>
];

engineSimplify[expression_, assumptions_] :=
  boundedSimplifyRoute[expression, assumptions, False]["OUTCOME"];
unrestrictedSimplify[expression_] :=
  boundedSimplifyRoute[expression, True, True]["OUTCOME"];

rankZeroTest[assumptions_] := Function[value, Module[{held, outcome},
  held = With[{heldValue = value, heldAssumptions = assumptions},
    HoldComplete[FullSimplify[heldValue == 0,
      Assumptions -> heldAssumptions]]];
  outcome = boundedCASAttempt[held, "ASSUMPTION_AWARE_ZERO_TEST",
    linearAlgebraBudgetFor[value]];
  If[resourceFailureQ[outcome], Throw[outcome, boundedLinearAlgebraAbort]];
  TrueQ[outcome]
]];

genericityCondition[variables_List] := And[
  And @@ (# != 0 & /@ variables),
  And @@ ((#[[1]] != #[[2]]) & /@ Subsets[variables, {2}])];

genericSpecializationRank[matrix_List, assumptions_, upperBound_] := Module[
  {allVariables, relevantVariables, instances, instance, pointRank,
   maximumRank},
  maximumRank = Min[Length[matrix],
    If[matrix === {}, 0, Length[First[matrix]]]];
  relevantVariables = orderedGlobalSymbols[matrix];
  allVariables = DeleteDuplicates[Join[relevantVariables,
    orderedGlobalSymbols[assumptions]]];
  instances = If[allVariables === {}, {{}},
    FindInstance[And[assumptions, genericityCondition[relevantVariables]],
      allVariables, Reals, 1]];
  If[! MatchQ[instances, {_List ..}],
    Return[Failure["GenericSpecializationUnavailable", <|
      "MATRIX" -> matrix, "ASSUMPTIONS" -> assumptions,
      "UPPER_BOUND" -> upperBound, "INSTANCE_OUTCOME" -> instances|>]]];
  instance = First[instances];
  pointRank = MatrixRank[matrix /. instance];
  If[! IntegerQ[pointRank],
    Return[Failure["SpecializedRankUnavailable", <|
      "MATRIX" -> matrix, "ASSUMPTIONS" -> assumptions,
      "UPPER_BOUND" -> upperBound, "INSTANCE" -> instance,
      "SPECIALIZED_RANK" -> pointRank|>]]];
  If[(IntegerQ[upperBound] && pointRank === upperBound) ||
      (SameQ[upperBound, Automatic] && pointRank === maximumRank),
    <|"RANK" -> pointRank, "INSTANCE" -> instance,
      "UPPER_BOUND" -> If[SameQ[upperBound, Automatic], maximumRank,
        upperBound]|>,
    Failure["SpecializationDidNotMeetRankUpperBound", <|
      "MATRIX" -> matrix, "ASSUMPTIONS" -> assumptions,
      "UPPER_BOUND" -> upperBound, "INSTANCE" -> instance,
      "SPECIALIZED_RANK" -> pointRank|>]
  ]
];

assumedRankRoute[matrix_List, assumptions_, upperBound_: Automatic,
    upperBoundCertificate_: tokenNotApplicable] := Module[
  {primaryHeld, primaryOutcome, fallbackHeld, fallbackOutcome, attempts,
   outcome, primaryBudget},
  primaryHeld = With[{heldMatrix = matrix, heldAssumptions = assumptions},
    HoldComplete[Catch[
      MatrixRank[heldMatrix,
        ZeroTest -> rankZeroTest[heldAssumptions]],
      boundedLinearAlgebraAbort]]];
  primaryBudget = linearAlgebraBudgetFor[matrix];
  primaryOutcome = boundedCASAttempt[primaryHeld,
    "PRIMARY_ASSUMED_MATRIX_RANK", primaryBudget];
  attempts = {<|"ATTEMPT" -> "PRIMARY_ASSUMED_MATRIX_RANK",
    "BUDGET_SECONDS" -> primaryBudget,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "ASSUMPTIONS" -> assumptions,
    "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];

  fallbackHeld = With[{heldMatrix = matrix,
      heldAssumptions = assumptions, heldUpperBound = upperBound},
    HoldComplete[genericSpecializationRank[heldMatrix, heldAssumptions,
      heldUpperBound]]];
  fallbackOutcome = boundedCASAttempt[fallbackHeld,
    "EXACT_GENERIC_SPECIALIZATION_RANK",
    linearAlgebraFallbackBudgetSeconds];
  AppendTo[attempts, <|
    "ATTEMPT" -> "EXACT_GENERIC_SPECIALIZATION_RANK",
    "BUDGET_SECONDS" -> linearAlgebraFallbackBudgetSeconds,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "ASSUMPTIONS" -> assumptions,
    "UPPER_BOUND" -> upperBound,
    "UPPER_BOUND_CERTIFICATE" -> upperBoundCertificate,
    "OUTCOME" -> fallbackOutcome|>];
  outcome = If[AssociationQ[fallbackOutcome] &&
      KeyExistsQ[fallbackOutcome, "RANK"],
    fallbackOutcome["RANK"], fallbackOutcome];
  <|"OUTCOME" -> outcome, "ATTEMPTS" -> attempts|>
];

assumedRank[matrix_List, assumptions_] :=
  assumedRankRoute[matrix, assumptions]["OUTCOME"];

genericPivotNullSpace[matrix_List, assumptions_, rank_Integer] := Module[
  {rowCount, columnCount, relevantVariables, allVariables, instances,
   instance, rowSets, columnSets, pivot, pivotRows, pivotColumns,
   freeColumns, pivotMatrix},
  rowCount = Length[matrix];
  columnCount = If[rowCount == 0, 0, Length[First[matrix]]];
  If[rank == 0, Return[IdentityMatrix[columnCount]]];
  If[rank == columnCount, Return[{}]];
  relevantVariables = orderedGlobalSymbols[matrix];
  allVariables = DeleteDuplicates[Join[relevantVariables,
    orderedGlobalSymbols[assumptions]]];
  instances = If[allVariables === {}, {{}},
    FindInstance[And[assumptions, genericityCondition[relevantVariables]],
      allVariables, Reals, 1]];
  If[! MatchQ[instances, {_List ..}],
    Return[Failure["NullSpaceSpecializationUnavailable", <|
      "MATRIX" -> matrix, "ASSUMPTIONS" -> assumptions,
      "RANK" -> rank, "INSTANCE_OUTCOME" -> instances|>]]];
  instance = First[instances];
  rowSets = Subsets[Range[rowCount], {rank}];
  columnSets = Subsets[Range[columnCount], {rank}];
  pivot = SelectFirst[Flatten[Table[{rows, columns}, {rows, rowSets},
      {columns, columnSets}], 1],
    ! TrueQ[PossibleZeroQ[Det[(matrix /. instance)[[#[[1]], #[[2]]]]]]] &,
    Missing["NoPivot"]];
  If[MissingQ[pivot],
    Return[Failure["NullSpacePivotUnavailable", <|
      "MATRIX" -> matrix, "ASSUMPTIONS" -> assumptions,
      "RANK" -> rank, "INSTANCE" -> instance|>]]];
  pivotRows = pivot[[1]];
  pivotColumns = pivot[[2]];
  freeColumns = Complement[Range[columnCount], pivotColumns];
  pivotMatrix = matrix[[pivotRows, pivotColumns]];
  Table[ReplacePart[UnitVector[columnCount, freeColumn],
    Thread[pivotColumns ->
      LinearSolve[pivotMatrix, -matrix[[pivotRows, freeColumn]]]]],
    {freeColumn, freeColumns}]
];

assumedNullSpaceRoute[matrix_List, assumptions_, rank_] := Module[
  {primaryHeld, primaryOutcome, fallbackHeld, fallbackOutcome, attempts,
   primaryBudget},
  primaryHeld = With[{heldMatrix = matrix, heldAssumptions = assumptions},
    HoldComplete[Catch[
      NullSpace[heldMatrix,
        ZeroTest -> rankZeroTest[heldAssumptions]],
      boundedLinearAlgebraAbort]]];
  primaryBudget = linearAlgebraBudgetFor[matrix];
  primaryOutcome = boundedCASAttempt[primaryHeld,
    "PRIMARY_ASSUMED_NULL_SPACE", primaryBudget];
  attempts = {<|"ATTEMPT" -> "PRIMARY_ASSUMED_NULL_SPACE",
    "BUDGET_SECONDS" -> primaryBudget,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "ASSUMPTIONS" -> assumptions,
    "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];
  If[! IntegerQ[rank],
    Return[<|"OUTCOME" -> Failure["NullSpaceRankUnavailable", <|
      "MATRIX" -> matrix, "ASSUMPTIONS" -> assumptions,
      "RANK" -> rank|>], "ATTEMPTS" -> attempts|>]];
  fallbackHeld = With[{heldMatrix = matrix,
      heldAssumptions = assumptions, heldRank = rank},
    HoldComplete[genericPivotNullSpace[heldMatrix, heldAssumptions,
      heldRank]]];
  fallbackOutcome = boundedCASAttempt[fallbackHeld,
    "EXACT_SPECIALIZED_PIVOT_NULL_SPACE",
    linearAlgebraFallbackBudgetSeconds];
  AppendTo[attempts, <|
    "ATTEMPT" -> "EXACT_SPECIALIZED_PIVOT_NULL_SPACE",
    "BUDGET_SECONDS" -> linearAlgebraFallbackBudgetSeconds,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "ASSUMPTIONS" -> assumptions,
    "RANK" -> rank, "OUTCOME" -> fallbackOutcome|>];
  <|"OUTCOME" -> fallbackOutcome, "ATTEMPTS" -> attempts|>
];

assumedNullSpace[matrix_List, assumptions_] := Module[{rankRoute},
  rankRoute = assumedRankRoute[matrix, assumptions];
  assumedNullSpaceRoute[matrix, assumptions, rankRoute["OUTCOME"]]["OUTCOME"]
];

relationResidual[relation_] := Which[
  TrueQ[relation], 0,
  SameQ[relation, False], 1,
  Head[relation] === Equal, Subtract @@ List @@ relation,
  True, relation
];

globalSymbolsIn[expression_] := DeleteDuplicates[Cases[
  expression, symbol_Symbol /; Context[symbol] === "Global`",
  {0, Infinity}]];

orderedGlobalSymbols[expression_] :=
  SortBy[globalSymbolsIn[expression], SymbolName];

truthStatus[testObject_] := Which[
  TrueQ[testObject], tokenProvedTrue,
  SameQ[testObject, False], tokenProvedFalse,
  True, tokenUndecided
];

reductionAnswerQ[result_] :=
  FreeQ[Unevaluated[result],
    _Reduce | Inactive[Reduce][___] | _Failure | HoldPattern[$Aborted]] &&
  MatchQ[Unevaluated[result],
    True | False | _Equal | _Unequal | _Less | _LessEqual | _Greater |
      _GreaterEqual | _Element | _And | _Or | _Not];

quantifiedExistenceObject[predicate_, variables_List] :=
  If[variables === {}, predicate,
    With[{quantifiedVariables = variables, quantifiedPredicate = predicate},
      Exists[quantifiedVariables, quantifiedPredicate]]];

exactRationalAssignments[variables_List] := Module[{dimension, constantRules,
    coordinateRules},
  dimension = Length[variables];
  constantRules = Table[
    MapThread[Rule, {variables, ConstantArray[value, dimension]}],
    {value, {0, 1, -1}}];
  coordinateRules = Flatten[Table[
    MapThread[Rule, {variables, ReplacePart[ConstantArray[0, dimension],
      coordinate -> value]}],
    {coordinate, dimension}, {value, {1, -1}}], 1];
  DeleteDuplicates[Join[constantRules, coordinateRules]]
];

exactRationalExistenceDecision[predicate_, variables_List, domain_] := Module[
  {specializations, specializedObjects, instances},
  If[variables === {},
    Return[unrestrictedSimplify[predicate]]];
  specializations = exactRationalAssignments[variables];
  specializedObjects = Quiet[
    unrestrictedSimplify[predicate /. #] & /@ specializations];
  If[AnyTrue[specializedObjects, TrueQ], Return[True]];
  instances = Quiet[FindInstance[predicate, variables, domain, 1]];
  Which[
    SameQ[instances, {}], False,
    MatchQ[instances, {_List ..}], True,
    True, Failure["ExactRationalExistenceUndecided", <|
      "PREDICATE" -> predicate,
      "VARIABLES" -> variables,
      "DOMAIN" -> domain,
      "SPECIALIZATIONS" -> specializations,
      "SPECIALIZED_OBJECTS" -> specializedObjects,
      "INSTANCE_OUTCOME" -> instances|>]
  ]
];

exactRationalDecision[testObject_, domain_] := Module[
  {quantifierVariables, predicate, existenceOutcome},
  Which[
    TrueQ[testObject] || SameQ[testObject, False], testObject,
    Head[testObject] === Exists,
      quantifierVariables = Flatten[{testObject[[1]]}];
      predicate = testObject[[2]];
      exactRationalExistenceDecision[predicate, quantifierVariables, domain],
    Head[testObject] === ForAll,
      quantifierVariables = Flatten[{testObject[[1]]}];
      predicate = testObject[[2]];
      existenceOutcome = exactRationalExistenceDecision[
        Not[predicate], quantifierVariables, domain];
      If[TrueQ[existenceOutcome] || SameQ[existenceOutcome, False],
        Not[existenceOutcome], existenceOutcome],
    MatchQ[Unevaluated[testObject], Not[_Exists]],
      quantifierVariables = Flatten[{testObject[[1, 1]]}];
      predicate = testObject[[1, 2]];
      existenceOutcome = exactRationalExistenceDecision[
        predicate, quantifierVariables, domain];
      If[TrueQ[existenceOutcome] || SameQ[existenceOutcome, False],
        Not[existenceOutcome], existenceOutcome],
    True, unrestrictedSimplify[testObject]
  ]
];

boundedQERoute[primaryExpression_HoldComplete, testObject_, domain_] := Module[
  {primaryTimeout, primaryMemory, primaryOutcome, exactTimeout, exactMemory,
   exactOutcome, attempts},
  primaryTimeout = Failure["QEBudgetExpired", <|
    "ATTEMPT" -> "PRIMARY_QE",
    "BUDGET_SECONDS" -> qePrimaryBudgetSeconds,
    "OPERAND" -> primaryExpression|>];
  primaryMemory = Failure["QEMemoryBudgetExpired", <|
    "RESOURCE" -> "MEMORY",
    "ATTEMPT" -> "PRIMARY_QE",
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> primaryExpression|>];
  primaryOutcome = TimeConstrained[
    MemoryConstrained[Quiet[ReleaseHold[primaryExpression]],
      casAttemptMemoryBudgetBytes, primaryMemory], qePrimaryBudgetSeconds,
    primaryTimeout];
  attempts = {<|
    "ATTEMPT" -> "PRIMARY_QE",
    "BUDGET_SECONDS" -> qePrimaryBudgetSeconds,
    "OPERAND" -> primaryExpression,
    "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];

  exactTimeout = Failure["QEBudgetExpired", <|
    "ATTEMPT" -> "EXACT_RATIONAL_DECISION",
    "BUDGET_SECONDS" -> qeExactRationalBudgetSeconds,
    "OPERAND" -> testObject,
    "DOMAIN" -> domain|>];
  exactMemory = Failure["QEMemoryBudgetExpired", <|
    "RESOURCE" -> "MEMORY",
    "ATTEMPT" -> "EXACT_RATIONAL_DECISION",
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> testObject,
    "DOMAIN" -> domain|>];
  exactOutcome = TimeConstrained[
    MemoryConstrained[Quiet[exactRationalDecision[testObject, domain]],
      casAttemptMemoryBudgetBytes, exactMemory],
    qeExactRationalBudgetSeconds, exactTimeout];
  AppendTo[attempts, <|
    "ATTEMPT" -> "EXACT_RATIONAL_DECISION",
    "BUDGET_SECONDS" -> qeExactRationalBudgetSeconds,
    "OPERAND" -> testObject,
    "DOMAIN" -> domain,
    "OUTCOME" -> exactOutcome|>];
  If[TrueQ[exactOutcome] || SameQ[exactOutcome, False],
    <|"OUTCOME" -> exactOutcome, "ATTEMPTS" -> attempts|>,
    <|"OUTCOME" -> testObject, "ATTEMPTS" -> attempts|>]
];

qeOperandsWithAttempts[operands_List, decision_Association] :=
  If[Length[decision["ATTEMPTS"]] < 2, operands,
    Append[operands, "QE_DECISION_ATTEMPTS" -> decision["ATTEMPTS"]]];

inconsistencyTestObject[reduction_] := Which[
  SameQ[reduction, False], True,
  reductionAnswerQ[reduction], False,
  True, reduction
];

admissibilityStatus[testObject_] := Which[
  TrueQ[testObject], tokenAdmissible,
  SameQ[testObject, False], tokenExcluded,
  True, tokenUndecided
];

fourWaySign[operand_, assumptions_] := Module[{positiveTest, negativeTest, zeroTestObject},
  positiveTest = engineSimplify[operand > 0, assumptions];
  negativeTest = engineSimplify[operand < 0, assumptions];
  zeroTestObject = engineSimplify[operand == 0, assumptions];
  Which[
    TrueQ[positiveTest], tokenPositive,
    TrueQ[negativeTest], tokenNegative,
    TrueQ[zeroTestObject], tokenZero,
    True, tokenUndecided
  ]
];

signPayload[operand_, assumptions_] := {
  "SIGN_TOKEN" -> fourWaySign[operand, assumptions],
  "OPERAND" -> operand
};

realExistenceDecision[condition_] := Module[
  {variables, testObject, primaryExpression},
  variables = orderedGlobalSymbols[condition];
  testObject = quantifiedExistenceObject[condition, variables];
  primaryExpression = If[variables === {}, HoldComplete[
      unrestrictedSimplify[condition]],
    With[{quantifiedVariables = variables, predicate = condition},
      HoldComplete[
        Resolve[Exists[quantifiedVariables, predicate], Reals]]]];
  boundedQERoute[primaryExpression, testObject, Reals]
];

exactProjectedInstance[condition_, projectedVariables_List] := Module[
  {allVariables, instances, instance, values},
  allVariables = DeleteDuplicates[Join[orderedGlobalSymbols[condition], projectedVariables]];
  instances = Quiet[If[allVariables === {},
    If[TrueQ[unrestrictedSimplify[condition]], {{}}, {}],
    With[{instanceVariables = allVariables, predicate = condition},
      FindInstance[predicate, instanceVariables, Reals, 1]]]];
  If[! ListQ[instances] || instances === {}, Return[tokenNotApplicable]];
  instance = First[instances];
  values = Table[variable /. instance, {variable, projectedVariables}];
  If[AnyTrue[MapThread[SameQ[#1, #2] &, {values, projectedVariables}], TrueQ],
    tokenNotApplicable,
    MapThread[(#1 -> #2) &, {projectedVariables, values}]
  ]
];

plainBranchRules[branch_] := Cases[branch, _Rule, {1}] /.
  Rule[left_, ConditionalExpression[right_, _]] :> Rule[left, right];

branchConditions[branch_] := Cases[
  branch, Rule[_, ConditionalExpression[_, condition_]] :> condition, {1}];

branchDefiningEquations[branch_] :=
  (#[[1]] == #[[2]] &) /@ plainBranchRules[branch];

conditionTerms[condition_] :=
  If[Head[condition] === And, List @@ condition, {condition}];

branchRelations[branch_] := Join[
  branchDefiningEquations[branch],
  Flatten[conditionTerms /@ branchConditions[branch], 1]
];

polynomialLocusQ[residuals_List] := And @@ Map[
  Function[residual,
    PolynomialQ[residual, orderedGlobalSymbols[residual]]],
  residuals
];

boundedNativeSolve[equations_, variables_List, attemptName_String,
    budgetSeconds_Integer] := Module[{held},
  held = With[{heldEquations = equations, heldVariables = variables},
    HoldComplete[Solve[heldEquations, heldVariables]]];
  boundedCASAttempt[held, attemptName, budgetSeconds]
];

factorSupportForSolve[residual_, variables_List] := Module[
  {numerator, factorPairs},
  numerator = Numerator[Together[residual]];
  If[TrueQ[numerator === 0], Return[{}]];
  factorPairs = Rest[FactorList[numerator]];
  DeleteDuplicates[Select[First /@ factorPairs,
    ! FreeQ[#, Alternatives @@ variables] &]]
];

factorLatticeSolve[equations_List, variables_List] := Module[
  {residuals, activeResiduals, supports, universe, hittingQ, hits,
   minimalHits, branchOutcomes},
  residuals = relationResidual /@ equations;
  activeResiduals = Select[residuals, ! TrueQ[# === 0] &];
  If[activeResiduals === {},
    Return[boundedNativeSolve[True, variables,
      "FACTOR_LATTICE_TAUTOLOGY_SOLVE", solveFallbackBudgetSeconds]]];
  supports = factorSupportForSolve[#, variables] & /@ activeResiduals;
  If[AnyTrue[supports, SameQ[#, {}] &],
    Return[Failure["FactorLatticeUnavailable", <|
      "EQUATIONS" -> equations, "SOLVE_VARIABLES" -> variables,
      "FACTOR_SUPPORTS" -> supports|>]]];
  universe = DeleteDuplicates[Flatten[supports]];
  hittingQ[hit_] := And @@
    (Intersection[hit, #, SameTest -> SameQ] =!= {} & /@ supports);
  hits = Select[Rest[Subsets[universe]], hittingQ];
  minimalHits = Select[hits, Function[hit,
    ! AnyTrue[hits, Function[other,
      Length[other] < Length[hit] && Complement[other, hit] === {}]]]];
  branchOutcomes = Table[
    boundedNativeSolve[And @@ (# == 0 & /@ hit), variables,
      "FACTOR_LATTICE_BRANCH_SOLVE", solveFallbackBudgetSeconds],
    {hit, minimalHits}];
  If[! And @@ (ListQ /@ branchOutcomes),
    Return[Failure["FactorLatticeBranchSolveUnavailable", <|
      "EQUATIONS" -> equations, "SOLVE_VARIABLES" -> variables,
      "MINIMAL_FACTOR_HITS" -> minimalHits,
      "BRANCH_OUTCOMES" -> branchOutcomes|>]]];
  DeleteDuplicates[Flatten[branchOutcomes, 1]]
];

boundedSolveRoute[equations_List, variables_List] := Module[
  {primaryHeld, primaryOutcome, fallbackHeld, fallbackOutcome, attempts,
   primaryBudget},
  primaryHeld = With[{heldEquations = equations, heldVariables = variables},
    HoldComplete[Solve[And @@ heldEquations, heldVariables]]];
  primaryBudget = primaryBudgetFor[equations, solvePrimaryBudgetSeconds];
  primaryOutcome = boundedCASAttempt[primaryHeld, "PRIMARY_SOLVE",
    primaryBudget];
  attempts = {<|"ATTEMPT" -> "PRIMARY_SOLVE",
    "BUDGET_SECONDS" -> primaryBudget,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> primaryHeld, "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];
  fallbackHeld = With[{heldEquations = equations,
      heldVariables = variables},
    HoldComplete[factorLatticeSolve[heldEquations, heldVariables]]];
  fallbackOutcome = boundedCASAttempt[fallbackHeld,
    "EXACT_FACTOR_LATTICE_SOLVE", solveFallbackBudgetSeconds];
  AppendTo[attempts, <|"ATTEMPT" -> "EXACT_FACTOR_LATTICE_SOLVE",
    "BUDGET_SECONDS" -> solveFallbackBudgetSeconds,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> fallbackHeld, "OUTCOME" -> fallbackOutcome|>];
  <|"OUTCOME" -> fallbackOutcome, "ATTEMPTS" -> attempts|>
];

solveOperandsWithAttempts[operands_List, decision_Association] :=
  If[Length[decision["ATTEMPTS"]] < 2, operands,
    Append[operands, "SOLUTION_ATTEMPTS" -> decision["ATTEMPTS"]]];

canonicalLocus[residuals_List, variables_List] := Module[{},
  If[! polynomialLocusQ[residuals], Return[tokenNotApplicable]];
  Quiet[GroebnerBasis[residuals, variables,
    MonomialOrder -> Lexicographic,
    CoefficientDomain -> RationalFunctions]]
];

emitLocus[package_String, dimension_Integer, baseQuantity_String,
    equations_List, variables_List, assumptions_] := Module[
  {solutionDecision, solutionPayload, solution, identityResiduals,
   identityOperands, identityTest,
   unrestrictedVariables, unrestrictedTestObject, unrestrictedExpression,
   unrestrictedDecision, unrestrictedReduction, inconsistentOperands,
   inconsistentTest, realAdmissible, admittedBranches, branch,
   branchDecision, branchOperands, branchTest,
   branchStatus, point, canonical, fullCondition, realTest, realStatus,
   realDecision, realWitness, realStatusOperands},
  emitCell[package, dimension, baseQuantity <> "_EQUATIONS", equations];
  solutionDecision = boundedSolveRoute[equations, variables];
  solution = solutionDecision["OUTCOME"];
  solutionPayload = {
    "SOLVE_VARIABLES" -> variables,
    "SOLUTION_SET" -> solution
  };
  solutionPayload = solveOperandsWithAttempts[solutionPayload,
    solutionDecision];
  emitCell[package, dimension, baseQuantity <> "_SOLUTION", solutionPayload];

  identityResiduals = relationResidual /@ equations;
  identityOperands = {"RESIDUALS" -> identityResiduals,
    "SOLVE_VARIABLES" -> variables};
  identityTest = unrestrictedSimplify[
    And @@ (# == 0 & /@ identityResiduals)];
  emitCell[package, dimension, baseQuantity <> "_IDENTICALLY_SATISFIED", {
    "STATUS_TOKEN" -> truthStatus[identityTest],
    "TEST_OBJECT" -> identityTest,
    "OPERANDS" -> identityOperands
  }];

  unrestrictedVariables = DeleteDuplicates[Join[variables,
    orderedGlobalSymbols[equations]]];
  unrestrictedTestObject = quantifiedExistenceObject[
    And @@ equations, unrestrictedVariables];
  unrestrictedExpression = With[
    {heldEquations = equations, heldVariables = variables},
    HoldComplete[Reduce[And @@ heldEquations, heldVariables, Complexes]]];
  unrestrictedDecision = boundedQERoute[unrestrictedExpression,
    unrestrictedTestObject, Complexes];
  unrestrictedReduction = unrestrictedDecision["OUTCOME"];
  inconsistentOperands = {"EQUATIONS" -> equations,
    "SOLVE_VARIABLES" -> variables,
    "UNRESTRICTED_REDUCTION" ->
      unrestrictedDecision["ATTEMPTS"][[1]]["OUTCOME"]};
  inconsistentTest = inconsistencyTestObject[unrestrictedReduction];
  inconsistentOperands = qeOperandsWithAttempts[
    inconsistentOperands, unrestrictedDecision];
  emitCell[package, dimension, baseQuantity <> "_INCONSISTENT", {
    "STATUS_TOKEN" -> truthStatus[inconsistentTest],
    "TEST_OBJECT" -> inconsistentTest,
    "OPERANDS" -> inconsistentOperands
  }];

  admittedBranches = {};
  realAdmissible = If[ListQ[solution],
    Table[
      branch = solution[[branchIndex]];
      branchDecision = realExistenceDecision[
        And[assumptions, And @@ branchRelations[branch]]];
      branchTest = branchDecision["OUTCOME"];
      branchOperands = qeOperandsWithAttempts[
        {"BRANCH" -> branch, "PREMISES" -> assumptions}, branchDecision];
      branchStatus = admissibilityStatus[branchTest];
      point = If[SameQ[branchStatus, tokenAdmissible],
        exactProjectedInstance[
          And[assumptions, And @@ branchRelations[branch]], variables],
        tokenNotApplicable];
      If[SameQ[branchStatus, tokenAdmissible],
        If[! ListQ[point],
          Throw[Failure["AdmittedBranchPointExtractionFailed", <|
            "Package" -> package,
            "Dimension" -> dimension,
            "LocusQuantity" -> baseQuantity,
            "BranchIndex" -> branchIndex,
            "Branch" -> branch,
            "SolveVariables" -> variables,
            "ReturnedObject" -> point|>], operationalFailure]];
        AppendTo[admittedBranches, <|
          "Branch" -> branch,
          "Rules" -> plainBranchRules[branch],
          "Equations" -> branchDefiningEquations[branch],
          "Variables" -> variables,
          "Point" -> point|>]];
      {
        "BRANCH" -> branch,
        "STATUS_TOKEN" -> branchStatus,
        "TEST_OBJECT" -> branchTest,
        "OPERANDS" -> branchOperands
      },
      {branchIndex, Length[solution]}],
    {{
      "BRANCH" -> solution,
      "STATUS_TOKEN" -> tokenUndecided,
      "TEST_OBJECT" -> Failure["OpaqueSolverResult", <|
        "SolverResult" -> solution|>],
      "OPERANDS" -> {"BRANCH" -> solution, "PREMISES" -> assumptions}
    }}
  ];
  emitCell[package, dimension, baseQuantity <> "_REAL_ADMISSIBLE", realAdmissible];

  canonical = canonicalLocus[identityResiduals, variables];
  emitCell[package, dimension, baseQuantity <> "_CANONICAL_LOCUS", canonical];

  fullCondition = And[assumptions, And @@ equations];
  realDecision = realExistenceDecision[fullCondition];
  realTest = realDecision["OUTCOME"];
  realStatus = Which[
    TrueQ[realTest], "PROVED_NONEMPTY",
    SameQ[realTest, False], "PROVED_EMPTY",
    True, tokenUndecided
  ];
  realWitness = If[SameQ[realStatus, "PROVED_NONEMPTY"],
    exactProjectedInstance[fullCondition, variables], tokenNotApplicable];
  If[SameQ[realStatus, "PROVED_NONEMPTY"] && ! ListQ[realWitness],
    realStatus = tokenUndecided;
    realWitness = tokenNotApplicable];
  emitCell[package, dimension, baseQuantity <> "_REAL_STATUS", realStatus];
  emitCell[package, dimension, baseQuantity <> "_REAL_WITNESS", realWitness];
  realStatusOperands = {
    "EQUATIONS" -> equations,
    "SOLVE_VARIABLES" -> variables,
    "PREMISES" -> assumptions,
    "TEST_OBJECT" -> realTest
  };
  realStatusOperands = qeOperandsWithAttempts[
    realStatusOperands, realDecision];
  emitCell[package, dimension, baseQuantity <> "_REAL_STATUS_OPERANDS",
    realStatusOperands];
  <|
    "BaseQuantity" -> baseQuantity,
    "Equations" -> equations,
    "Variables" -> variables,
    "Solution" -> solution,
    "RealAdmissible" -> realAdmissible,
    "AdmittedBranches" -> admittedBranches,
    "RealStatus" -> realStatus,
    "RealWitness" -> realWitness|>
];

coordinateFrame[dimension_Integer] := Module[
  {spaceCoordinates, timeCoordinate, fieldHeads, arguments, fields, gradient},
  spaceCoordinates = Table[Symbol["x" <> ToString[index]], {index, dimension}];
  timeCoordinate = Symbol["t"];
  fieldHeads = Table[Symbol["u" <> ToString[index]], {index, dimension}];
  arguments = Join[spaceCoordinates, {timeCoordinate}];
  fields = (#[Sequence @@ arguments] &) /@ fieldHeads;
  gradient = Table[D[fields[[column]], spaceCoordinates[[row]]],
    {row, dimension}, {column, dimension}];
  <|
    "X" -> spaceCoordinates,
    "T" -> timeCoordinate,
    "Heads" -> fieldHeads,
    "Arguments" -> arguments,
    "Fields" -> fields,
    "Gradient" -> gradient|>
];

curlDensity[gradient_] := Module[{dimension = Length[gradient]},
  1/2 Total[Flatten[Table[
    (gradient[[row, column]] - gradient[[column, row]])^2,
    {row, dimension}, {column, dimension}]]]
];

divDensity[gradient_] := Tr[gradient]^2;

symtlDensity[gradient_] := Module[{dimension = Length[gradient], tracelessPart},
  tracelessPart = (gradient + Transpose[gradient])/2 -
    Tr[gradient] IdentityMatrix[dimension]/dimension;
  Total[Flatten[tracelessPart^2]]
];

quadraticCoordinates[polynomial_, variables_, pairs_] := Map[
  Function[pair,
    If[pair[[1]] === pair[[2]],
      Coefficient[Expand[polynomial], variables[[pair[[1]]]], 2],
      Coefficient[
        Coefficient[Expand[polynomial], variables[[pair[[1]]]], 1],
        variables[[pair[[2]]]], 1]
    ]],
  pairs
];

polynomialFromCoordinates[row_, monomials_] :=
  Expand[Total[MapThread[Times, {row, monomials}]]];

eulerOperatorForGradientDensity[polynomial_, gradientVariables_, frame_] := Module[
  {dimension, gradient, spaceCoordinates},
  dimension = Length[frame["X"]];
  gradient = frame["Gradient"];
  spaceCoordinates = frame["X"];
  Table[
    Expand[Total[Table[
      D[D[polynomial, gradientVariables[[(row - 1) dimension + column]]] /.
        Thread[gradientVariables -> Flatten[gradient]], spaceCoordinates[[row]]],
      {row, dimension}]]],
    {column, dimension}]
];

buildInvariantCensus[dimension_Integer, package_String] := Module[
  {variableCount, gradientVariables, gradientMatrix, pairs, monomials,
   generators, variationVariables, actionRows, connectedConstraints,
   v1Raw, v1Basis, v1Dimension, reflection, reflectedGradient,
   reflectionRows, fullConstraints, v2Raw, v2Basis, v2Dimension,
   v1Polynomials, reflectedPolynomials, v4Residual, v4Sum, frame,
   v5Euler, pivots, coordinateActionRows, v6Operator, v6Coordinates,
   v6Ambient, v6Basis, v6Dimension, pdPolynomial},
  variableCount = dimension^2;
  gradientVariables = Table[Symbol["g" <> ToString[index]],
    {index, variableCount}];
  gradientMatrix = Partition[gradientVariables, dimension];
  pairs = Flatten[Table[{left, right}, {left, variableCount},
    {right, left, variableCount}], 1];
  monomials = (gradientVariables[[#[[1]]]] gradientVariables[[#[[2]]]] &) /@ pairs;
  emitCell[package, dimension, "MONOMIAL_ORDERING", monomials];

  generators = Flatten[Table[
    SparseArray[{{row, column} -> 1, {column, row} -> -1},
      {dimension, dimension}],
    {row, 1, dimension - 1}, {column, row + 1, dimension}], 1];
  connectedConstraints = If[generators === {},
    SparseArray[{}, {0, Length[monomials]}],
    SparseArray[Join @@ Table[
      variationVariables = Flatten[
        generators[[generatorIndex]].gradientMatrix -
          gradientMatrix.generators[[generatorIndex]]];
      actionRows = Table[
        quadraticCoordinates[
          Expand[Total[MapThread[
            (D[monomials[[monomialIndex]], #1] #2) &,
            {gradientVariables, variationVariables}]]],
          gradientVariables, pairs],
        {monomialIndex, Length[monomials]}];
      Transpose[actionRows],
      {generatorIndex, Length[generators]}]]];
  v1Raw = NullSpace[connectedConstraints];
  v1Basis = If[v1Raw === {}, {}, RowReduce[v1Raw]];
  v1Dimension = Length[v1Basis];
  emitCell[package, dimension, "V1_BASIS", v1Basis];
  emitCell[package, dimension, "V1_DIM", v1Dimension];

  reflection = DiagonalMatrix[Join[{-1}, ConstantArray[1, dimension - 1]]];
  reflectedGradient = Expand[reflection.gradientMatrix.Transpose[reflection]];
  reflectionRows = Table[
    quadraticCoordinates[
      monomials[[monomialIndex]] /.
        Thread[gradientVariables -> Flatten[reflectedGradient]],
      gradientVariables, pairs],
    {monomialIndex, Length[monomials]}];
  fullConstraints = Join[connectedConstraints,
    SparseArray[Transpose[reflectionRows - IdentityMatrix[Length[monomials]]]]];
  v2Raw = NullSpace[fullConstraints];
  v2Basis = If[v2Raw === {}, {}, RowReduce[v2Raw]];
  v2Dimension = Length[v2Basis];
  emitCell[package, dimension, "V2_BASIS", v2Basis];
  emitCell[package, dimension, "V2_DIM", v2Dimension];
  emitCell[package, dimension, "V3_DIFFERENCE", v1Dimension - v2Dimension];

  emitCell[package, dimension, "R0_MATRIX", reflection];
  emitCell[package, dimension, "R0_ORTHOGONALITY_RESIDUAL",
    Transpose[reflection].reflection - IdentityMatrix[dimension]];
  emitCell[package, dimension, "R0_DETERMINANT", Det[reflection]];

  v1Polynomials = polynomialFromCoordinates[#, monomials] & /@ v1Basis;
  reflectedPolynomials = Expand[# /.
      Thread[gradientVariables -> Flatten[reflectedGradient]]] & /@ v1Polynomials;
  v4Residual = MapThread[Expand[#1 - #2] &,
    {reflectedPolynomials, v1Polynomials}];
  v4Sum = MapThread[Expand[#1 + #2] &,
    {reflectedPolynomials, v1Polynomials}];
  emitCell[package, dimension, "V4_REFLECTED", reflectedPolynomials];
  emitCell[package, dimension, "V4_RESIDUAL", v4Residual];
  emitCell[package, dimension, "V4_SUM", v4Sum];

  frame = coordinateFrame[dimension];
  v5Euler = eulerOperatorForGradientDensity[#, gradientVariables, frame] & /@
    v1Polynomials;
  emitCell[package, dimension, "V5_EULER_LAGRANGE", v5Euler];

  If[v1Dimension == 0,
    v6Operator = {};
    v6Basis = {},
    pivots = FirstPosition[#, 1][[1]] & /@ v1Basis;
    coordinateActionRows = Table[
      quadraticCoordinates[reflectedPolynomials[[basisIndex]],
        gradientVariables, pairs][[pivots]],
      {basisIndex, v1Dimension}];
    v6Operator = Transpose[coordinateActionRows];
    v6Coordinates = NullSpace[v6Operator + IdentityMatrix[v1Dimension]];
    v6Ambient = (#.v1Basis) & /@ v6Coordinates;
    v6Basis = If[v6Ambient === {}, {}, RowReduce[v6Ambient]]
  ];
  v6Dimension = Length[v6Basis];
  emitCell[package, dimension, "V6_OPERATOR", v6Operator];
  emitCell[package, dimension, "V6_BASIS", v6Basis];
  emitCell[package, dimension, "V6_DIM", v6Dimension];
  emitCell[package, dimension, "V7_RESIDUAL",
    v6Dimension - (v1Dimension - v2Dimension)];

  pdPolynomial = Expand[Total[
    polynomialFromCoordinates[#, monomials] & /@ v6Basis]];
  <|
    "D" -> dimension,
    "GVariables" -> gradientVariables,
    "GMatrix" -> gradientMatrix,
    "Monomials" -> monomials,
    "V1Basis" -> v1Basis,
    "V1Dim" -> v1Dimension,
    "V2Basis" -> v2Basis,
    "V2Dim" -> v2Dimension,
    "R0" -> reflection,
    "V1Polynomials" -> v1Polynomials,
    "ReflectedPolynomials" -> reflectedPolynomials,
    "V4Residual" -> v4Residual,
    "V4Sum" -> v4Sum,
    "V5Euler" -> v5Euler,
    "V6Operator" -> v6Operator,
    "V6Basis" -> v6Basis,
    "V6Dim" -> v6Dimension,
    "PDPolynomial" -> pdPolynomial|>
];

emitInvariantCensus[data_, package_String, dimension_Integer] := Module[{},
  emitCell[package, dimension, "MONOMIAL_ORDERING", data["Monomials"]];
  emitCell[package, dimension, "V1_BASIS", data["V1Basis"]];
  emitCell[package, dimension, "V1_DIM", Length[data["V1Basis"]]];
  emitCell[package, dimension, "V2_BASIS", data["V2Basis"]];
  emitCell[package, dimension, "V2_DIM", Length[data["V2Basis"]]];
  emitCell[package, dimension, "V3_DIFFERENCE",
    Length[data["V1Basis"]] - Length[data["V2Basis"]]];
  emitCell[package, dimension, "R0_MATRIX", data["R0"]];
  emitCell[package, dimension, "R0_ORTHOGONALITY_RESIDUAL",
    Transpose[data["R0"]].data["R0"] - IdentityMatrix[dimension]];
  emitCell[package, dimension, "R0_DETERMINANT", Det[data["R0"]]];
  emitCell[package, dimension, "V4_REFLECTED", data["ReflectedPolynomials"]];
  emitCell[package, dimension, "V4_RESIDUAL", data["V4Residual"]];
  emitCell[package, dimension, "V4_SUM", data["V4Sum"]];
  emitCell[package, dimension, "V5_EULER_LAGRANGE", data["V5Euler"]];
  emitCell[package, dimension, "V6_OPERATOR", data["V6Operator"]];
  emitCell[package, dimension, "V6_BASIS", data["V6Basis"]];
  emitCell[package, dimension, "V6_DIM", Length[data["V6Basis"]]];
  emitCell[package, dimension, "V7_RESIDUAL",
    Length[data["V6Basis"]] -
      (Length[data["V1Basis"]] - Length[data["V2Basis"]])];
];

stiffnessBlueprint[package_String] := Switch[package,
  "MAIN" | "XKIN_ANISO", {{muR/2, "curl"}, {bComp/2, "div"}},
  "XFORM_CURLONLY", {{muR/2, "curl"}},
  "XFORM_DIVONLY", {{bComp/2, "div"}},
  "XFORM_TRACELESS", {{muR/2, "curl"}, {muBr, "symtl"}},
  "XFORM_EXTRA", {{muR/2, "curl"}, {bComp/2, "div"}, {beta/2, "pd"}},
  "XCOEF_BSCALE", {{muR/2, "curl"}, {s bComp/2, "div"}},
  "XCOEF_BSIGN", {{muR/2, "curl"}, {-bComp/2, "div"}}
];

kineticRecords[package_String, velocityJet_List] := If[package === "XKIN_ANISO",
  {
    <|"Factor" -> rhoBr/2, "DensityJet" -> Total[Rest[velocityJet]^2]|>,
    <|"Factor" -> sRho rhoBr/2, "DensityJet" -> First[velocityJet]^2|>
  },
  {<|"Factor" -> rhoBr/2, "DensityJet" -> Total[velocityJet^2]|>}
];

stiffnessRecords[package_String, densityJet_, densityCoordinate_] := Map[
  Function[item, <|
    "Factor" -> item[[1]],
    "Kind" -> item[[2]],
    "DensityJet" -> densityJet[item[[2]]],
    "DensityCoordinate" -> densityCoordinate[item[[2]]]|>],
  stiffnessBlueprint[package]
];

makePremises[package_String, dimension_Integer, wavevector_List,
    amplitudes_List] := Module[{symbolicEntries, packageEntries, symbolicJoint},
  symbolicEntries = {
    rhoBr > 0,
    muR > 0,
    bComp > 0,
    Total[wavevector^2] > 0,
    And @@ (Element[#, Reals] & /@ wavevector),
    And @@ (Element[#, Reals] & /@ amplitudes),
    Element[dimensionSymbol, Integers] && dimensionSymbol > 0
  };
  packageEntries = Switch[package,
    "XFORM_TRACELESS", {muBr > 0},
    "XFORM_EXTRA", {Element[beta, Reals]},
    "XCOEF_BSCALE", {s > 0, s != 1},
    "XKIN_ANISO", {sRho > 0, sRho != 1},
    _, {}
  ];
  symbolicJoint = And @@ Join[symbolicEntries, packageEntries];
  <|
    "SymbolicEntries" -> Join[symbolicEntries, packageEntries],
    "SymbolicJoint" -> symbolicJoint,
    "AtDimension" -> (symbolicJoint /. dimensionSymbol -> dimension)|>
];

premiseInventory[premises_, package_String, dimension_Integer,
    amplitudes_List] := {
  "JOINT_SYMBOLIC_ASSUMPTIONS" -> premises["SymbolicJoint"],
  "PACKAGE" -> package,
  "BRANE_DIMENSION" -> dimension,
  "DISPLACEMENT_DIMENSION" -> {1, 0, 0},
  "IN_PLANE_COMPONENTS" -> amplitudes,
  "OUT_OF_PLANE_FIELD_EXCLUDED" -> hBranon,
  "BACKGROUND_VELOCITY" -> 0,
  "DISSIPATIVE_TERMS" -> {},
  "MAXIMUM_FIELD_DEGREE" -> 2,
  "WALL_WIDTH_FIELDS" -> {},
  "REAL_PHASE_ANSATZ" -> Cos,
  "PHASE_AVERAGE_DOMAIN" -> {phaseVariable, 0, 2 Pi},
  "DIMENSIONLESS_COEFFICIENTS" ->
    If[package === "XCOEF_BSCALE", {s}, {}],
  "BULK_MODE_CONTENT" -> {ScalarSoundMode},
  "BULK_AMPLITUDE_PREMISE" -> Element[A, Reals],
  "BULK_SPEED_PREMISE" -> cs0 > 0,
  "INTERFACE_EQUATIONS_SUPPLIED" -> {}
};

multiplicativeFactors[expression_] := Module[{factored = Factor[expression]},
  If[Head[factored] === Times, List @@ factored, {factored}]
];

routeAStrippedFactor[planeExpressions_, amplitudes_, phaseCoordinates_List] := Module[
  {coefficientEntries, nonzeroEntries, commonFactors, phaseFactors},
  coefficientEntries = Flatten[Table[
    Coefficient[planeExpressions[[row]], amplitudes[[column]]],
    {row, Length[planeExpressions]}, {column, Length[amplitudes]}]];
  nonzeroEntries = Select[coefficientEntries, ! TrueQ[# === 0] &];
  commonFactors = If[nonzeroEntries === {}, {},
    Fold[Intersection[#1, #2, SameTest -> SameQ] &,
      multiplicativeFactors[First[nonzeroEntries]],
      multiplicativeFactors /@ Rest[nonzeroEntries]]];
  phaseFactors = Select[commonFactors,
    ! FreeQ[#, Alternatives @@ phaseCoordinates] &];
  If[phaseFactors === {}, Missing["NoCommonPhaseFactor"], Times @@ phaseFactors]
];

coefficientOrderingFromRecords[kineticRecordsList_, stiffnessRecordsList_] := Module[
  {factors, inertialCoefficients},
  factors = Join[Lookup[kineticRecordsList, "Factor"],
    Lookup[stiffnessRecordsList, "Factor"]];
  inertialCoefficients = Flatten[globalSymbolsIn /@ Lookup[kineticRecordsList, "Factor"]];
  SortBy[DeleteDuplicates[Join[
    Flatten[globalSymbolsIn /@ factors], inertialCoefficients]], SymbolName]
];

mergeMultiplicityPairs[pairs_List, assumptions_] := Fold[
  Function[{accumulator, pair}, Module[{position, index},
    position = FirstPosition[accumulator,
      existing_List /; Length[existing] == 2 &&
        TrueQ[engineSimplify[existing[[1]] == pair[[1]], assumptions]],
      Missing["NotFound"], {1}];
    If[MissingQ[position], Append[accumulator, pair],
      index = First[position];
      ReplacePart[accumulator, position -> {
        accumulator[[index, 1]],
        accumulator[[index, 2]] + pair[[2]]}]]
  ]],
  {}, pairs
];

rootMultiplicityPairs[determinant_, assumptions_] := Module[
  {polynomial, factorPairs, rawPairs, solutionDecision, solutions, roots},
  polynomial = Numerator[Together[determinant]];
  factorPairs = Select[Rest[FactorList[polynomial]],
    ! FreeQ[First[#], omegaSquared] &];
  rawPairs = Catch[Flatten[Map[
    Function[factorPair,
      solutionDecision = boundedSolveRoute[
        {factorPair[[1]] == 0}, {omegaSquared}];
      solutions = solutionDecision["OUTCOME"];
      If[! ListQ[solutions],
        Throw[Failure["RootFactorSolveUnavailable", <|
          "FACTOR_PAIR" -> factorPair,
          "SOLUTION_DECISION" -> solutionDecision|>], rootFactorFailure]];
      roots = omegaSquared /. solutions;
      ({#, factorPair[[2]]} &) /@ roots],
    factorPairs], 1], rootFactorFailure];
  If[Head[rawPairs] === Failure, Return[rawPairs]];
  mergeMultiplicityPairs[rawPairs, assumptions]
];

distinctUnderAssumptions[values_List, assumptions_] := DeleteDuplicates[
  values, TrueQ[engineSimplify[#1 == #2, assumptions]] &];

constructMaximalMinors[matrix_, rank_Integer, factorPresentation_] := Module[
  {rowSets, columnSets},
  If[rank == 0, Return[{}]];
  rowSets = Subsets[Range[Length[matrix]], {rank}];
  columnSets = Subsets[Range[Length[First[matrix]]], {rank}];
  Flatten[Table[
    If[TrueQ[factorPresentation],
      Factor[Det[matrix[[rowSet, columnSet]]]],
      Det[matrix[[rowSet, columnSet]]]],
    {rowSet, rowSets}, {columnSet, columnSets}]]
];

maximalMinorsRoute[matrix_, rank_Integer] := Module[
  {primaryHeld, primaryOutcome, fallbackHeld, fallbackOutcome, attempts,
   primaryBudget},
  primaryHeld = With[{heldMatrix = matrix, heldRank = rank},
    HoldComplete[constructMaximalMinors[heldMatrix, heldRank, True]]];
  primaryBudget = primaryBudgetFor[matrix, minorPrimaryBudgetSeconds];
  primaryOutcome = boundedCASAttempt[primaryHeld,
    "PRIMARY_FACTORED_MAXIMAL_MINORS", primaryBudget];
  attempts = {<|"ATTEMPT" -> "PRIMARY_FACTORED_MAXIMAL_MINORS",
    "BUDGET_SECONDS" -> primaryBudget,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "RANK" -> rank,
    "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];
  fallbackHeld = With[{heldMatrix = matrix, heldRank = rank},
    HoldComplete[constructMaximalMinors[heldMatrix, heldRank, False]]];
  fallbackOutcome = boundedCASAttempt[fallbackHeld,
    "EXACT_UNFACTORED_MAXIMAL_MINORS", minorFallbackBudgetSeconds];
  AppendTo[attempts, <|"ATTEMPT" -> "EXACT_UNFACTORED_MAXIMAL_MINORS",
    "BUDGET_SECONDS" -> minorFallbackBudgetSeconds,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "RANK" -> rank,
    "OUTCOME" -> fallbackOutcome|>];
  <|"OUTCOME" -> fallbackOutcome, "ATTEMPTS" -> attempts|>
];

allMaximalMinors[matrix_, rank_Integer] :=
  maximalMinorsRoute[matrix, rank]["OUTCOME"];

factoredDeterminantRoute[matrix_] := Module[
  {primaryHeld, primaryOutcome, fallbackHeld, fallbackOutcome, attempts,
   primaryBudget},
  primaryHeld = With[{heldMatrix = matrix},
    HoldComplete[Factor[Det[heldMatrix]]]];
  primaryBudget = primaryBudgetFor[matrix, minorPrimaryBudgetSeconds];
  primaryOutcome = boundedCASAttempt[primaryHeld,
    "PRIMARY_FACTORED_DETERMINANT", primaryBudget];
  attempts = {<|"ATTEMPT" -> "PRIMARY_FACTORED_DETERMINANT",
    "BUDGET_SECONDS" -> primaryBudget,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "OUTCOME" -> primaryOutcome|>};
  If[! resourceFailureQ[primaryOutcome],
    Return[<|"OUTCOME" -> primaryOutcome, "ATTEMPTS" -> attempts|>]];
  fallbackHeld = With[{heldMatrix = matrix}, HoldComplete[Det[heldMatrix]]];
  fallbackOutcome = boundedCASAttempt[fallbackHeld,
    "EXACT_UNFACTORED_DETERMINANT", minorFallbackBudgetSeconds];
  AppendTo[attempts, <|"ATTEMPT" -> "EXACT_UNFACTORED_DETERMINANT",
    "BUDGET_SECONDS" -> minorFallbackBudgetSeconds,
    "BUDGET_BYTES" -> casAttemptMemoryBudgetBytes,
    "OPERAND" -> matrix, "OUTCOME" -> fallbackOutcome|>];
  <|"OUTCOME" -> fallbackOutcome, "ATTEMPTS" -> attempts|>
];

unscopedQuantity[scope_String, pointEvidence_, quantity_String] :=
  scope <> If[TrueQ[pointEvidence], "POINT_EVIDENCE_", ""] <> quantity;

rootQuantity[scope_String, pointEvidence_, rootIndex_Integer, quantity_String] :=
  scope <> "ROOT" <> ToString[rootIndex] <> "_" <>
    If[TrueQ[pointEvidence], "POINT_EVIDENCE_", ""] <> quantity;

changeLocusSuffixes = {
  "EQUATIONS", "SOLUTION", "IDENTICALLY_SATISFIED", "INCONSISTENT",
  "REAL_ADMISSIBLE", "CANONICAL_LOCUS", "REAL_STATUS", "REAL_WITNESS",
  "REAL_STATUS_OPERANDS"};

componentCountStatus[attemptOutcome_] := Which[
  TrueQ[attemptOutcome], tokenConstant,
  SameQ[attemptOutcome, False], tokenVaries,
  True, tokenUndecided
];

countDecisionAttempt[componentObject_, countPredicate_, changeEquations_List,
    freeParameters_List, assumptions_] := Module[
  {universalVariables, testObject, primaryExpression, decision,
   attemptOutcome},
  universalVariables = DeleteDuplicates[Join[freeParameters,
    orderedGlobalSymbols[And[assumptions, countPredicate]]]];
  testObject = If[universalVariables === {},
    Implies[assumptions, countPredicate],
    With[{variables = universalVariables,
      predicate = Implies[assumptions, countPredicate]},
      ForAll[variables, predicate]]];
  primaryExpression = With[{heldTestObject = testObject},
    HoldComplete[Resolve[heldTestObject, Reals]]];
  decision = boundedQERoute[primaryExpression, testObject, Reals];
  attemptOutcome = decision["OUTCOME"];
  <|
    "COMPONENT_OBJECT" -> componentObject,
    "TEST_OBJECT" -> testObject,
    "ATTEMPT_OUTCOME" -> attemptOutcome,
    "QE_DECISION_ATTEMPTS" -> decision["ATTEMPTS"],
    "CHANGE_EQUATIONS" -> changeEquations,
    "ASSUMPTIONS" -> assumptions|>
];

unavailableCountDecision[componentObject_, returnedObject_, assumptions_: True] := <|
  "COMPONENT_OBJECT" -> componentObject,
  "TEST_OBJECT" -> returnedObject,
  "ATTEMPT_OUTCOME" -> returnedObject,
  "CHANGE_EQUATIONS" -> {},
  "ASSUMPTIONS" -> assumptions|>;

polynomialDegreeDecision[polynomial_, variable_, degree_, freeParameters_List,
    assumptions_, componentObject_] := Module[{leadingCoefficient},
  If[! IntegerQ[degree] || degree < 0,
    Return[unavailableCountDecision[componentObject,
      Failure["PolynomialDegreeDecisionUnavailable", <|
        "Polynomial" -> polynomial,
        "Variable" -> variable,
        "ObtainedDegree" -> degree|>], assumptions]]];
  leadingCoefficient = Coefficient[polynomial, variable, degree];
  countDecisionAttempt[componentObject, leadingCoefficient != 0,
    {leadingCoefficient == 0}, freeParameters, assumptions]
];

distinctRootDecision[polynomial_, variable_, degree_, roots_List,
    freeParameters_List, assumptions_] := Module[
  {leadingCoefficient, polynomialDerivative, polynomialGCD, squareFreePart,
   squareFreeDegree, squareFreeLeadingCoefficient, squareFreeDiscriminant,
   nonvanishingFactors, changePolynomial, countPredicate},
  If[! IntegerQ[degree] || degree < 0,
    Return[unavailableCountDecision[
      <|"POLYNOMIAL" -> polynomial, "ROOTS" -> roots|>,
      Failure["DistinctRootDecisionUnavailable", <|
        "Polynomial" -> polynomial,
        "Variable" -> variable,
        "ObtainedDegree" -> degree,
        "ObtainedRoots" -> roots|>], assumptions]]];
  leadingCoefficient = Coefficient[polynomial, variable, degree];
  polynomialDerivative = D[polynomial, variable];
  polynomialGCD = PolynomialGCD[polynomial, polynomialDerivative];
  squareFreePart = Cancel[polynomial/polynomialGCD];
  squareFreeDegree = Exponent[squareFreePart, variable];
  If[! IntegerQ[squareFreeDegree] || squareFreeDegree =!= Length[roots],
    Return[unavailableCountDecision[
      <|"POLYNOMIAL" -> polynomial, "ROOTS" -> roots|>,
      Failure["SquareFreeDegreeDecisionUnavailable", <|
        "SQUARE_FREE_PART" -> squareFreePart,
        "SQUARE_FREE_DEGREE" -> squareFreeDegree,
        "OBTAINED_ROOT_COUNT" -> Length[roots]|>], assumptions]]];
  squareFreeLeadingCoefficient = Coefficient[
    squareFreePart, variable, squareFreeDegree];
  squareFreeDiscriminant = If[squareFreeDegree <= 1, 1,
    Discriminant[squareFreePart, variable]];
  nonvanishingFactors = {leadingCoefficient, squareFreeLeadingCoefficient,
    squareFreeDiscriminant};
  countPredicate = And @@ (# != 0 & /@ nonvanishingFactors);
  changePolynomial = Numerator[Together[Times @@ nonvanishingFactors]];
  countDecisionAttempt[
    <|"POLYNOMIAL" -> polynomial, "ROOTS" -> roots|>, countPredicate,
    {changePolynomial == 0}, freeParameters, assumptions]
];

matrixRankDecision[matrix_List, rank_, freeParameters_List, assumptions_,
    algebraRoute_: <||>] :=
  Module[{minors, countPredicate, changeEquations, decision,
    algebraAttempts},
    If[! IntegerQ[rank] || rank < 0,
      Return[unavailableCountDecision[matrix,
        Failure["MatrixRankDecisionUnavailable", <|
          "Matrix" -> matrix, "ObtainedRank" -> rank|>], assumptions]]];
    If[rank == 0,
      countPredicate = And @@ (# == 0 & /@ Flatten[matrix]);
      changeEquations = {1 == 0},
      minors = allMaximalMinors[matrix, rank];
      If[! ListQ[minors],
        Return[unavailableCountDecision[matrix,
          Failure["MaximalMinorConstructionUnavailable", <|
            "Matrix" -> matrix, "Rank" -> rank,
            "MINOR_OUTCOME" -> minors|>], assumptions]]];
      countPredicate = Or @@ (# != 0 & /@ minors);
      changeEquations = (# == 0) & /@ minors
    ];
    decision = countDecisionAttempt[matrix, countPredicate, changeEquations,
      freeParameters, assumptions];
    algebraAttempts = If[AssociationQ[algebraRoute],
      Lookup[algebraRoute, "ATTEMPTS", {}], {}];
    If[Length[algebraAttempts] > 1,
      AssociateTo[decision,
        "ALGEBRA_DECISION_ATTEMPTS" -> algebraAttempts]];
    decision
  ];

emitComponentCount[package_, dimension_, baseQuantity_String, value_,
    freeParameters_List, decision_Association] := Module[
  {status, countAttempts, algebraAttempts, nullSpaceAttempts,
   certificateOperands, certificate, countRecord, decisionOperands},
  status = componentCountStatus[decision["ATTEMPT_OUTCOME"]];
  countAttempts = Lookup[decision, "QE_DECISION_ATTEMPTS", {}];
  algebraAttempts = Lookup[decision, "ALGEBRA_DECISION_ATTEMPTS", {}];
  nullSpaceAttempts = Lookup[decision, "NULL_SPACE_ATTEMPTS", {}];
  certificateOperands = {
    "VALUE" -> value,
    "FREE_PARAMETERS" -> freeParameters,
    "ATTEMPT_OUTCOME" -> If[countAttempts === {},
      decision["ATTEMPT_OUTCOME"], countAttempts[[1]]["OUTCOME"]]
  };
  If[Length[countAttempts] > 1,
    AppendTo[certificateOperands, "QE_DECISION_ATTEMPTS" -> countAttempts]];
  certificate = If[SameQ[status, tokenConstant], {
      "FREE_PARAMETERS" -> freeParameters,
      "TEST_OBJECT" -> decision["TEST_OBJECT"],
      "OPERANDS" -> certificateOperands
    }, tokenNotApplicable];
  countRecord = {
    "STATUS_TOKEN" -> status,
    "VALUE" -> value
  };
  If[Length[countAttempts] > 1,
    AppendTo[countRecord, "QE_DECISION_ATTEMPTS" -> countAttempts]];
  If[Length[algebraAttempts] > 1,
    AppendTo[countRecord,
      "ALGEBRA_DECISION_ATTEMPTS" -> algebraAttempts]];
  If[Length[nullSpaceAttempts] > 1,
    AppendTo[countRecord,
      "NULL_SPACE_ATTEMPTS" -> nullSpaceAttempts]];
  If[SameQ[status, tokenUndecided],
    decisionOperands = {
      "COMPONENT_OBJECT" -> decision["COMPONENT_OBJECT"],
      "TEST_OBJECT" -> decision["TEST_OBJECT"],
      "FREE_PARAMETERS" -> freeParameters,
      "PREMISES" -> decision["ASSUMPTIONS"]};
    AppendTo[countRecord, "DECISION_OPERANDS" -> decisionOperands]];
  emitCell[package, dimension, baseQuantity, countRecord];
  emitCell[package, dimension, baseQuantity <> "_STATUS", status];
  emitCell[package, dimension, baseQuantity <> "_CONSTANCY_CERTIFICATE", certificate];
  If[SameQ[status, tokenVaries],
    emitLocus[package, dimension, baseQuantity <> "_CHANGE_LOCUS",
      decision["CHANGE_EQUATIONS"], freeParameters, decision["ASSUMPTIONS"]],
    Scan[Function[suffix,
      emitCell[package, dimension,
        baseQuantity <> "_CHANGE_LOCUS_" <> suffix, tokenNotApplicable]],
      changeLocusSuffixes]
  ];
  status
];

emitCountObject[package_, dimension_, baseQuantity_String, value_,
    componentCounts_, freeParameters_List, decision_] := If[TrueQ[componentCounts],
  emitComponentCount[package, dimension, baseQuantity, value, freeParameters,
    decision],
  emitCell[package, dimension, baseQuantity, value];
  tokenNotApplicable
];

candidateRecords[locus_, sourceToken_, sourceLocusTag_] := Map[
  Function[branchRecord, Join[branchRecord, <|
    "Source" -> sourceToken,
    "SourceLocusTag" -> sourceLocusTag|>]],
  locus["AdmittedBranches"]
];

computeSpectrumAndModes[matrix_, coefficients_List, wavevector_List, assumptions_,
    package_String, dimension_Integer, scope_String, pointEvidence_,
    includeRankLoci_, componentCounts_, freeParameters_List,
    activeKVariables_List, activeCoefficientVariables_List] := Module[
  {determinantRoute, determinant, determinantPolynomial, multiplicityPairs,
   solverDecision, solverSolution,
   degree, rootCountAll,
   roots, rootCountDistinct, rootCountStatuses = {}, pairIndices,
   coincidenceEquations, coincidenceK, coincidenceCoefficient,
   coincidenceCandidates = {}, rankCandidates = {}, stackedCandidates = {},
   rootObjects, root, rootBase, matrixAtRoot, rank, nullity, stacked,
   stackedRank, transverseNullity, basis, basisDots, basisResiduals,
   basisCount, mDotK, rankMinors, stackedMinors, rankEquations, stackedEquations,
   rankKLocus, rankCoefficientLocus, rankJointLocus, stackedKLocus,
   stackedCoefficientLocus, stackedJointLocus, rootCountBase,
   countStatus, degreeDecision, rootCountAllDecision, distinctDecision,
   rankRoute, stackedRankRoute, nullSpaceRoute, rankDecision,
   stackedDecision, basisCountDecision, q4Derived = {}, rootPrefix,
   rootUpperBoundCertificate},
  determinantRoute = factoredDeterminantRoute[matrix];
  determinant = determinantRoute["OUTCOME"];
  determinantPolynomial = Numerator[Together[determinant]];
  emitCell[package, dimension,
    unscopedQuantity[scope, pointEvidence, "DET_M"], determinant];
  multiplicityPairs = rootMultiplicityPairs[determinant, assumptions];
  emitCell[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_MULTIPLICITY_PAIRS"],
    multiplicityPairs];
  solverDecision = boundedSolveRoute[{determinant == 0}, {omegaSquared}];
  solverSolution = solverDecision["OUTCOME"];
  emitCell[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_SOLUTION_SET"],
    solverSolution];
  rootCountAll = Total[Last /@ multiplicityPairs];
  degree = Exponent[determinantPolynomial, omegaSquared];
  degreeDecision = If[TrueQ[componentCounts],
    polynomialDegreeDecision[determinantPolynomial, omegaSquared, degree,
      freeParameters, assumptions,
      <|"DETERMINANT" -> determinant,
        "MULTIPLICITY_PAIRS" -> multiplicityPairs|>],
    tokenNotApplicable];
  rootCountAllDecision = If[TrueQ[componentCounts] &&
      ! SameQ[rootCountAll, degree],
    unavailableCountDecision[multiplicityPairs,
      Failure["RootMultiplicityCountDecisionUnavailable", <|
        "MULTIPLICITY_PAIRS" -> multiplicityPairs,
        "OBTAINED_COUNT" -> rootCountAll,
        "POLYNOMIAL_DEGREE" -> degree|>], assumptions],
    degreeDecision];
  rootCountBase = unscopedQuantity[scope, pointEvidence, "ROOT_COUNT_ALL"];
  countStatus = emitCountObject[package, dimension, rootCountBase, rootCountAll,
    componentCounts, freeParameters, rootCountAllDecision];
  If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
  countStatus = emitCountObject[package, dimension,
    unscopedQuantity[scope, pointEvidence, "DET_M_DEGREE"], degree,
    componentCounts, freeParameters, degreeDecision];
  If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
  rootCountAllDecision = tokenNotApplicable;
  degreeDecision = tokenNotApplicable;
  emitCell[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_DEGREE_RESIDUAL"],
    degree - rootCountAll];
  roots = distinctUnderAssumptions[First /@ multiplicityPairs, assumptions];
  emitCell[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_DISTINCT"], roots];
  rootCountDistinct = Length[roots];
  distinctDecision = If[TrueQ[componentCounts],
    distinctRootDecision[determinantPolynomial, omegaSquared, degree, roots,
      freeParameters, assumptions], tokenNotApplicable];
  countStatus = emitCountObject[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_COUNT_DISTINCT"],
    rootCountDistinct, componentCounts, freeParameters, distinctDecision];
  If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
  distinctDecision = tokenNotApplicable;
  emitCell[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_ORDERING"], roots];

  Do[
    rootBase = rootQuantity[scope, pointEvidence, rootIndex, "VALUE"];
    emitCell[package, dimension, rootBase, roots[[rootIndex]]];
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "SIGN"],
      signPayload[roots[[rootIndex]], assumptions]],
    {rootIndex, Length[roots]}];

  pairIndices = Subsets[Range[Length[roots]], {2}];
  coincidenceEquations = (engineSimplify[
      roots[[#[[1]]]] - roots[[#[[2]]]], assumptions] == 0) & /@ pairIndices;
  coincidenceK = emitLocus[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_COINCIDENCE_K"],
    coincidenceEquations, activeKVariables, assumptions];
  coincidenceCoefficient = emitLocus[package, dimension,
    unscopedQuantity[scope, pointEvidence, "ROOT_COINCIDENCE_COEFF"],
    coincidenceEquations, activeCoefficientVariables, assumptions];
  If[TrueQ[includeRankLoci],
    coincidenceCandidates = Join[
      candidateRecords[coincidenceK, tokenRootCoincidence,
        standardEmissionName[cellEmission[package, dimension,
          unscopedQuantity[scope, pointEvidence, "ROOT_COINCIDENCE_K"]]]],
      candidateRecords[coincidenceCoefficient, tokenRootCoincidence,
        standardEmissionName[cellEmission[package, dimension,
          unscopedQuantity[scope, pointEvidence, "ROOT_COINCIDENCE_COEFF"]]]]
    ]];

  rootObjects = Table[
    root = roots[[rootIndex]];
    matrixAtRoot = Map[engineSimplify[#, assumptions] &,
      matrix /. omegaSquared -> root, {2}];
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N1"], matrixAtRoot];
    rootUpperBoundCertificate = {
      "SOURCE_DETERMINANT" -> determinant,
      "SOURCE_ROOT" -> root,
      "SOURCE_ROOT_SOLUTION" -> solverSolution};
    rankRoute = assumedRankRoute[matrixAtRoot, assumptions,
      dimension - 1, rootUpperBoundCertificate];
    rank = rankRoute["OUTCOME"];
    rankDecision = If[TrueQ[componentCounts],
      matrixRankDecision[matrixAtRoot, rank, freeParameters, assumptions,
        rankRoute],
      tokenNotApplicable];
    countStatus = emitCountObject[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N2_RANK"], rank,
      componentCounts, freeParameters, rankDecision];
    If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
    nullity = dimension - rank;
    countStatus = emitCountObject[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N2_NULLITY"], nullity,
      componentCounts, freeParameters, rankDecision];
    If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
    stacked = Join[matrixAtRoot, {wavevector}];
    stackedRankRoute = assumedRankRoute[stacked, assumptions, dimension,
      {"COLUMN_COUNT" -> dimension}];
    stackedRank = stackedRankRoute["OUTCOME"];
    stackedDecision = If[TrueQ[componentCounts],
      matrixRankDecision[stacked, stackedRank, freeParameters, assumptions,
        stackedRankRoute],
      tokenNotApplicable];
    countStatus = emitCountObject[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N3_STACKED_RANK"],
      stackedRank, componentCounts, freeParameters, stackedDecision];
    If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
    transverseNullity = dimension - stackedRank;
    countStatus = emitCountObject[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N3_TRANSVERSE_NULLITY"],
      transverseNullity, componentCounts, freeParameters, stackedDecision];
    If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
    stackedDecision = tokenNotApplicable;
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N4_NULLITY_DIFFERENCE"],
      nullity - transverseNullity];
    mDotK = Map[engineSimplify[#, assumptions] &, matrixAtRoot.wavevector];
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N5_M_DOT_K"], mDotK];
    nullSpaceRoute = assumedNullSpaceRoute[matrixAtRoot, assumptions, rank];
    basis = nullSpaceRoute["OUTCOME"];
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N6_BASIS"], basis];
    (* An exhausted null-space route is an opaque computed return.  Propagate
       that exact Failure through dependent slots instead of mapping algebra
       over Failure's tag/payload or manufacturing Length[Failure] == 2. *)
    basisDots = computedOrOpaqueFailure[basis,
      Map[engineSimplify[#.wavevector, assumptions] &, basis]];
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N6_DOT_K"], basisDots];
    basisResiduals = computedOrOpaqueFailure[basis,
      MapThread[
        Function[{basisVector, dotProduct},
          Map[engineSimplify[#, assumptions] &,
            Total[wavevector^2] basisVector - dotProduct wavevector]],
        {basis, basisDots}]];
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N6_RESIDUAL"],
      basisResiduals];
    basisCount = computedOrOpaqueFailure[basis, Length[basis]];
    basisCountDecision = If[TrueQ[componentCounts] &&
        ! SameQ[basisCount, nullity],
      unavailableCountDecision[basis,
        Failure["NullSpaceBasisCountDecisionUnavailable", <|
          "BASIS" -> basis,
          "OBTAINED_COUNT" -> basisCount,
          "RANK_DERIVED_NULLITY" -> nullity|>], assumptions],
      rankDecision];
    If[AssociationQ[basisCountDecision] &&
        Length[nullSpaceRoute["ATTEMPTS"]] > 1,
      AssociateTo[basisCountDecision,
        "NULL_SPACE_ATTEMPTS" -> nullSpaceRoute["ATTEMPTS"]]];
    countStatus = emitCountObject[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N7_BASIS_COUNT"],
      basisCount, componentCounts, freeParameters, basisCountDecision];
    If[TrueQ[componentCounts], AppendTo[rootCountStatuses, countStatus]];
    basisCountDecision = tokenNotApplicable;
    rankDecision = tokenNotApplicable;
    emitCell[package, dimension,
      rootQuantity[scope, pointEvidence, rootIndex, "N7_RESIDUAL"],
      computedOrOpaqueFailure[basisCount, basisCount - nullity]];

    If[TrueQ[includeRankLoci],
      rankMinors = allMaximalMinors[matrixAtRoot, rank];
      emitCell[package, dimension,
        rootQuantity[scope, pointEvidence, rootIndex, "RANK_DROP_MINORS"],
        rankMinors];
      rankEquations = (# == 0) & /@ rankMinors;
      rootPrefix = rootQuantity[scope, pointEvidence, rootIndex, "RANK_DROP_K"];
      rankKLocus = emitLocus[package, dimension, rootPrefix, rankEquations,
        activeKVariables, assumptions];
      rankCandidates = Join[rankCandidates,
        candidateRecords[rankKLocus, tokenRankDrop,
          standardEmissionName[cellEmission[package, dimension, rootPrefix]]]];
      rootPrefix = rootQuantity[scope, pointEvidence, rootIndex, "RANK_DROP_COEFF"];
      rankCoefficientLocus = emitLocus[package, dimension, rootPrefix,
        rankEquations, activeCoefficientVariables, assumptions];
      rankCandidates = Join[rankCandidates,
        candidateRecords[rankCoefficientLocus, tokenRankDrop,
          standardEmissionName[cellEmission[package, dimension, rootPrefix]]]];
      rootPrefix = rootQuantity[scope, pointEvidence, rootIndex, "RANK_DROP_JOINT"];
      rankJointLocus = emitLocus[package, dimension, rootPrefix, rankEquations,
        Join[activeKVariables, activeCoefficientVariables], assumptions];
      rankCandidates = Join[rankCandidates,
        candidateRecords[rankJointLocus, tokenRankDrop,
          standardEmissionName[cellEmission[package, dimension, rootPrefix]]]];

      stackedMinors = allMaximalMinors[stacked, stackedRank];
      emitCell[package, dimension,
        rootQuantity[scope, pointEvidence, rootIndex, "STACKED_DROP_MINORS"],
        stackedMinors];
      stackedEquations = (# == 0) & /@ stackedMinors;
      rootPrefix = rootQuantity[scope, pointEvidence, rootIndex, "STACKED_DROP_K"];
      stackedKLocus = emitLocus[package, dimension, rootPrefix,
        stackedEquations, activeKVariables, assumptions];
      stackedCandidates = Join[stackedCandidates,
        candidateRecords[stackedKLocus, tokenStackedDrop,
          standardEmissionName[cellEmission[package, dimension, rootPrefix]]]];
      rootPrefix = rootQuantity[scope, pointEvidence, rootIndex, "STACKED_DROP_COEFF"];
      stackedCoefficientLocus = emitLocus[package, dimension, rootPrefix,
        stackedEquations, activeCoefficientVariables, assumptions];
      stackedCandidates = Join[stackedCandidates,
        candidateRecords[stackedCoefficientLocus, tokenStackedDrop,
          standardEmissionName[cellEmission[package, dimension, rootPrefix]]]];
      rootPrefix = rootQuantity[scope, pointEvidence, rootIndex, "STACKED_DROP_JOINT"];
      stackedJointLocus = emitLocus[package, dimension, rootPrefix,
        stackedEquations, Join[activeKVariables, activeCoefficientVariables],
        assumptions];
      stackedCandidates = Join[stackedCandidates,
        candidateRecords[stackedJointLocus, tokenStackedDrop,
          standardEmissionName[cellEmission[package, dimension, rootPrefix]]]]
    ];
    AppendTo[q4Derived, <|
      "MDotK" -> mDotK,
      "BasisResiduals" -> basisResiduals|>];
    <|
      "Root" -> root,
      "Matrix" -> matrixAtRoot,
      "Rank" -> rank,
      "Nullity" -> nullity,
      "Stacked" -> stacked,
      "StackedRank" -> stackedRank,
      "Basis" -> basis,
      "BasisResiduals" -> basisResiduals|>,
    {rootIndex, Length[roots]}];
  <|
    "Determinant" -> determinant,
    "MultiplicityPairs" -> multiplicityPairs,
    "Roots" -> roots,
    "RootObjects" -> rootObjects,
    "Q4Derived" -> q4Derived,
    "Candidates" -> Join[rankCandidates, stackedCandidates,
      coincidenceCandidates],
    "CountStatuses" -> rootCountStatuses|>
];

dimensionVectorsEqualQ[left_, right_, assumptions_] :=
  ListQ[left] && ListQ[right] && Length[left] == Length[right] &&
    TrueQ[engineSimplify[And @@ Thread[left == right], assumptions]];

rationalExponentQ[exponent_, assumptions_] := TrueQ[
  IntegerQ[exponent] || MatchQ[Unevaluated[exponent], _Rational] ||
    engineSimplify[Element[exponent, Rationals], assumptions]
];

dimensionOfScalar[expression_, atomDimensions_, assumptions_] := Module[
  {pieces, dimensions, uniqueDimensions, baseDimension},
  Which[
    NumberQ[expression], {0, 0, 0},
    KeyExistsQ[atomDimensions, Unevaluated[expression]],
      atomDimensions[Unevaluated[expression]],
    Head[expression] === ConditionalExpression,
      dimensionOfScalar[expression[[1]], atomDimensions, assumptions],
    Head[expression] === Plus,
      pieces = List @@ expression;
      dimensions = dimensionOfScalar[#, atomDimensions, assumptions] & /@ pieces;
      uniqueDimensions = DeleteDuplicates[dimensions,
        dimensionVectorsEqualQ[#1, #2, assumptions] &];
      If[Length[uniqueDimensions] == 1, First[uniqueDimensions],
        DimensionalAlternatives @@ uniqueDimensions],
    Head[expression] === Times,
      dimensions = dimensionOfScalar[#, atomDimensions, assumptions] & /@
        (List @@ expression);
      If[And @@ (ListQ /@ dimensions), Total[dimensions],
        DimensionalProduct[dimensions]],
    Head[expression] === Power &&
        rationalExponentQ[expression[[2]], assumptions],
      baseDimension = dimensionOfScalar[expression[[1]], atomDimensions, assumptions];
      If[ListQ[baseDimension], expression[[2]] baseDimension,
        DimensionalPower[baseDimension, expression[[2]]]],
    True, UnknownDimension[expression]
  ]
];

dimensionOfDeclaredTerm[record_, atomDimensions_, assumptions_] := Module[
  {density, factorDimension, densityDimension},
  density = record["DensityJet"];
  If[TrueQ[density === 0], Return[ZeroFormDimensionUndetermined[density]]];
  factorDimension = dimensionOfScalar[record["Factor"], atomDimensions, assumptions];
  densityDimension = dimensionOfScalar[density, atomDimensions, assumptions];
  If[ListQ[factorDimension] && ListQ[densityDimension],
    factorDimension + densityDimension,
    DimensionalProduct[{factorDimension, densityDimension}]]
];

expandedTerms[expression_] := If[TrueQ[expression === 0], {},
  If[Head[Expand[expression]] === Plus, List @@ Expand[expression],
    {Expand[expression]}]];

homogeneityRecord[objectName_String, expression_, atomDimensions_, assumptions_] := Module[
  {scalars, termDimensions, referenceDimensions, testObject},
  scalars = If[ListQ[expression], Flatten[expression], {expression}];
  termDimensions = Map[
    Function[scalar,
      dimensionOfScalar[#, atomDimensions, assumptions] & /@ expandedTerms[scalar]],
    scalars];
  referenceDimensions = DeleteDuplicates[Flatten[termDimensions, 1],
    dimensionVectorsEqualQ[#1, #2, assumptions] &];
  testObject = If[referenceDimensions === {}, True,
    And[And @@ (ListQ /@ referenceDimensions), Length[referenceDimensions] == 1]];
  {
    "OBJECT_NAME" -> objectName,
    "EXPRESSION" -> expression,
    "TERM_DIMENSIONS" -> termDimensions,
    "TEST_OBJECT" -> testObject
  }
];

buildDimensions[coefficientOrdering_List, actionRecords_List, velocityJet_List,
    gradientVariables_List, amplitudes_List, wavevector_List, assumptions_,
    package_String, dimension_Integer] := Module[
  {dimensionlessCoefficients, unknownCoefficients, dimensionVariables,
   coefficientDimensions, baseAtomDimensions, targetDimension, termDimensions,
   equationVectors, dimensionEquations, flatUnknowns, solutionDecision,
   solution, solutionRules,
   finalCoefficientDimensions, firstSlotVariables, firstSlotExpressions,
   coefficientMatrix, equationCount, unknownCount, determinacy,
   finalAtomDimensions, actionHomogeneity, soundSpeedDimensionVariables,
   soundSpeedDimensionEquations, soundSpeedDimensionDecision,
   soundSpeedDimensionSolution,
   soundSpeedDimension},
  dimensionlessCoefficients = If[MemberQ[coefficientOrdering, s], {s}, {}];
  unknownCoefficients = Select[coefficientOrdering,
    ! MemberQ[dimensionlessCoefficients, #] &];
  dimensionVariables = Association@Table[
    coefficient -> Table[
      Symbol["dim" <> SymbolName[coefficient] <> "Slot" <> ToString[slot]],
      {slot, 3}],
    {coefficient, unknownCoefficients}];
  coefficientDimensions = Association@Table[
    coefficient -> If[MemberQ[dimensionlessCoefficients, coefficient],
      {0, 0, 0}, dimensionVariables[coefficient]],
    {coefficient, coefficientOrdering}];
  baseAtomDimensions = Join[coefficientDimensions,
    AssociationThread[velocityJet,
      ConstantArray[{1, -1, 0}, Length[velocityJet]]],
    AssociationThread[gradientVariables,
      ConstantArray[{0, 0, 0}, Length[gradientVariables]]],
    AssociationThread[amplitudes,
      ConstantArray[{1, 0, 0}, Length[amplitudes]]],
    AssociationThread[wavevector,
      ConstantArray[{-1, 0, 0}, Length[wavevector]]],
    <|omegaSquared -> {0, -2, 0}, lambdaScale -> {0, 0, 0},
      kwSquared -> {-2, 0, 0}|>];
  targetDimension = {2 - dimensionSymbol, -2, 1};
  termDimensions = dimensionOfDeclaredTerm[#, baseAtomDimensions, assumptions] & /@
    actionRecords;
  equationVectors = Select[termDimensions, ListQ];
  dimensionEquations = Flatten[Thread[# == targetDimension] & /@ equationVectors];
  flatUnknowns = Flatten[Values[dimensionVariables]];
  solutionDecision = boundedSolveRoute[dimensionEquations, flatUnknowns];
  solution = solutionDecision["OUTCOME"];
  emitCell[package, dimension, "DIM_EQUATIONS", dimensionEquations];
  emitCell[package, dimension, "DIM_SOLUTION", solution];
  solutionRules = If[ListQ[solution] && solution =!= {}, First[solution], {}];
  finalCoefficientDimensions = Table[
    {coefficient,
      engineSimplify[coefficientDimensions[coefficient] /. solutionRules,
        assumptions]},
    {coefficient, coefficientOrdering}];
  emitCell[package, dimension, "DIM_COEFFICIENTS", finalCoefficientDimensions];

  firstSlotVariables = If[unknownCoefficients === {}, {},
    dimensionVariables[#][[1]] & /@ unknownCoefficients];
  firstSlotExpressions = If[equationVectors === {}, {},
    (#[[1]] - targetDimension[[1]]) & /@ equationVectors];
  coefficientMatrix = If[firstSlotVariables === {} || firstSlotExpressions === {}, {},
    Normal[Last[CoefficientArrays[firstSlotExpressions, firstSlotVariables]]]];
  equationCount = If[firstSlotVariables === {} || firstSlotExpressions === {}, 0,
    assumedRank[coefficientMatrix, assumptions]];
  unknownCount = Length[unknownCoefficients];
  determinacy = Which[
    ! ListQ[solution] || solution === {}, tokenOverDetermined,
    equationCount > unknownCount, tokenOverDetermined,
    equationCount < unknownCount, tokenUnderDetermined,
    True, tokenExactlyDetermined
  ];
  emitCell[package, dimension, "DIM_EQUATION_COUNT", equationCount];
  emitCell[package, dimension, "DIM_UNKNOWN_COUNT", unknownCount];
  emitCell[package, dimension, "DIM_COUNT_DIFFERENCE", equationCount - unknownCount];
  emitCell[package, dimension, "DIM_DETERMINACY", determinacy];

  soundSpeedDimensionVariables = Table[
    Symbol["dimCs0Slot" <> ToString[slot]], {slot, 3}];
  soundSpeedDimensionEquations = Thread[
    2 soundSpeedDimensionVariables + {-2, 0, 0} == {0, -2, 0}];
  soundSpeedDimensionDecision = boundedSolveRoute[
    soundSpeedDimensionEquations, soundSpeedDimensionVariables];
  soundSpeedDimensionSolution = soundSpeedDimensionDecision["OUTCOME"];
  soundSpeedDimension = soundSpeedDimensionVariables /.
    First[soundSpeedDimensionSolution];
  finalAtomDimensions = Join[baseAtomDimensions /. solutionRules,
    <|cs0 -> soundSpeedDimension|>];
  actionHomogeneity = Table[
    homogeneityRecord["ACTION_TERM_" <> ToString[index],
      actionRecords[[index]]["Factor"] actionRecords[[index]]["DensityJet"],
      finalAtomDimensions, assumptions],
    {index, Length[actionRecords]}];
  emitCell[package, dimension, "DIM_HOMOGENEITY_ACTION", actionHomogeneity];
  <|
    "CoefficientDimensions" -> finalCoefficientDimensions,
    "AtomDimensions" -> finalAtomDimensions,
    "Solution" -> solution,
    "SolutionRules" -> solutionRules|>
];

emitScaledRoots[spectrum_, wavevector_List, assumptions_, package_String,
    dimension_Integer] := Module[
  {root, scaled, ratio, numeratorExponent, denominatorExponent, candidate,
   exponent, scaleAssumptions},
  scaleAssumptions = And[assumptions, lambdaScale > 0];
  Do[
    root = spectrum["Roots"][[rootIndex]];
    scaled = engineSimplify[root /. Thread[wavevector -> lambdaScale wavevector],
      scaleAssumptions];
    emitCell[package, dimension, "ROOT" <> ToString[rootIndex] <> "_SCALED", scaled];
    emitCell[package, dimension, "ROOT" <> ToString[rootIndex] <> "_UNSCALED", root];
    If[TrueQ[engineSimplify[root == 0, assumptions]],
      ratio = tokenUndefinedRatio;
      exponent = tokenUndefinedRatio,
      ratio = engineSimplify[scaled/root, scaleAssumptions];
      numeratorExponent = Exponent[Numerator[Together[ratio]], lambdaScale];
      denominatorExponent = Exponent[Denominator[Together[ratio]], lambdaScale];
      candidate = numeratorExponent - denominatorExponent;
      exponent = If[TrueQ[engineSimplify[ratio == lambdaScale^candidate,
          scaleAssumptions]], candidate, tokenNotPurePower]
    ];
    emitCell[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_SCALE_RATIO", ratio];
    emitCell[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_SCALE_EXPONENT", exponent],
    {rootIndex, Length[spectrum["Roots"]]}]
];

emitQ7[stiffnessRecordList_, coordinateGradient_, independentGradient_,
    package_String, dimension_Integer] := Module[
  {gradientRules, fullStiffness, curlTerm, unweightedCurl, leviCivita,
   curlVector, curlReference, residual},
  gradientRules = Thread[Flatten[coordinateGradient] -> Flatten[independentGradient]];
  fullStiffness = Total[(#["Factor"] #["DensityCoordinate"]) & /@
      stiffnessRecordList] /. gradientRules;
  curlTerm = Total[Map[
      Function[record, If[record["Kind"] === "curl",
        record["Factor"] record["DensityCoordinate"], 0]],
      stiffnessRecordList]] /. gradientRules;
  unweightedCurl = curlDensity[coordinateGradient] /. gradientRules;
  leviCivita = LeviCivitaTensor[dimension];
  curlVector = Table[Total[Flatten[Table[
      leviCivita[[component, row, column]] independentGradient[[row, column]],
      {row, dimension}, {column, dimension}]]],
    {component, dimension}];
  curlReference = Expand[curlVector.curlVector];
  residual = Expand[unweightedCurl - curlReference];
  emitCell[package, dimension, "Q7_W_FULL", Expand[fullStiffness]];
  emitCell[package, dimension, "Q7_CURL_TERM", Expand[curlTerm]];
  emitCell[package, dimension, "Q7_CURL_DENSITY", Expand[unweightedCurl]];
  emitCell[package, dimension, "Q7_CURL_REFERENCE", curlReference];
  emitCell[package, dimension, "Q7_RESIDUAL", residual];
  residual
];

sourceOrder = {tokenRankDrop, tokenStackedDrop, tokenRootCoincidence};
sourcePosition[source_] := FirstPosition[sourceOrder, source][[1]];

mergeCandidates[candidates_List] := Module[{merged = {}, key, position, record},
  Do[
    record = candidates[[candidateIndex]];
    key = ToString[record["Branch"],
      InputForm, PageWidth -> Infinity];
    position = FirstPosition[merged,
      existing_Association /; SameQ[existing["Key"], key],
      Missing["NotFound"], {1}];
    If[MissingQ[position],
      AppendTo[merged, <|
        "Key" -> key,
        "Branch" -> record["Branch"],
        "Rules" -> record["Rules"],
        "Equations" -> record["Equations"],
        "Variables" -> record["Variables"],
        "Point" -> record["Point"],
        "Contributors" -> {{record["Source"], record["SourceLocusTag"]}}|>],
      merged[[First[position], "Contributors"]] = DeleteDuplicates[
        Append[merged[[First[position], "Contributors"]],
          {record["Source"], record["SourceLocusTag"]}]];
      merged[[First[position], "Variables"]] = DeleteDuplicates[Join[
        merged[[First[position], "Variables"]], record["Variables"]]]
    ],
    {candidateIndex, Length[candidates]}];
  merged
];

componentFreeParameters[restrictedMatrix_, wavevector_List,
    coefficients_List] := Select[DeleteDuplicates[Join[wavevector, coefficients]],
  ! FreeQ[restrictedMatrix, #] &];

failureJacobianPayload[componentRoots_, coefficientOrdering_, equations_, point_] := {
  "FAILURE_TOKEN" -> "MISSING_TANGENT_COORDINATES_AND_OFF_STRATUM_EXTENSION",
  "RECOMPUTED_ROOTS" -> componentRoots,
  "COEFFICIENT_ORDERING" -> coefficientOrdering,
  "DEFINING_EQUATIONS" -> equations,
  "EVALUATION_POINT" -> point
};

emitStrata[candidates_List, matrix_, genericRootJacobian_, coefficients_List,
    wavevector_List, assumptions_, package_String, dimension_Integer] := Module[
  {strata, ordering, stratum, contributors, sources, sourceTags, scope,
   restrictionRules, restrictedMatrix, restrictedAssumptions, freeParameters,
   activeK, activeCoefficients, componentSpectrum, coverage, point,
   pointMatrix, pointAssumptions, pointActiveK, pointActiveCoefficients,
   pointSpectrum, restrictedJacobian},
  strata = Map[
    Function[component,
      Append[component, "Point" -> exactProjectedInstance[
        And[assumptions, And @@ component["Equations"]],
        component["Variables"]]]],
    mergeCandidates[candidates]];
  ordering = Lookup[strata, "Branch", {}];
  emitCell[package, dimension, "STRATUM_ORDERING", ordering];
  Do[
    stratum = strata[[stratumIndex]];
    scope = "STRATUM" <> ToString[stratumIndex] <> "_";
    contributors = SortBy[stratum["Contributors"],
      sourcePosition[First[#]] &];
    sources = DeleteDuplicates[First /@ contributors];
    sourceTags = Last /@ contributors;
    restrictionRules = stratum["Rules"];
    restrictedMatrix = Map[engineSimplify[#,
          assumptions /. restrictionRules] &,
      matrix /. restrictionRules, {2}];
    restrictedAssumptions = engineSimplify[assumptions /. restrictionRules, True];
    freeParameters = componentFreeParameters[restrictedMatrix, wavevector, coefficients];
    point = stratum["Point"];

    emitCell[package, dimension, scope <> "SOURCES", sources];
    emitCell[package, dimension, scope <> "SOURCE_LOCUS_TAGS", sourceTags];
    emitCell[package, dimension, scope <> "DEFINING_EQUATIONS",
      stratum["Equations"]];
    emitCell[package, dimension, scope <> "FREE_PARAMETERS", freeParameters];
    If[! ListQ[point],
      Throw[Failure["StratumPointExtractionFailed", <|
        "Package" -> package,
        "Dimension" -> dimension,
        "StratumIndex" -> stratumIndex,
        "Branch" -> stratum["Branch"],
        "DefiningEquations" -> stratum["Equations"],
        "SolveVariables" -> stratum["Variables"],
        "ReturnedObject" -> point|>], operationalFailure]];
    emitCell[package, dimension, scope <> "POINT", point];

    activeK = Select[wavevector, MemberQ[freeParameters, #] &];
    activeCoefficients = Select[coefficients, MemberQ[freeParameters, #] &];
    componentSpectrum = computeSpectrumAndModes[restrictedMatrix, coefficients,
      wavevector, restrictedAssumptions, package, dimension, scope, False,
      False, True, freeParameters, activeK, activeCoefficients];
    coverage = If[And @@ (MemberQ[{tokenConstant, tokenVaries}, #] & /@
          componentSpectrum["CountStatuses"]),
      tokenCompleteCoverage, tokenIncompleteCoverage];
    emitCell[package, dimension, scope <> "COMPONENT_Q3_Q4_COVERAGE", coverage];
    ClearSystemCache[];

    pointMatrix = Map[engineSimplify[#, assumptions /. point] &,
      matrix /. point, {2}];
    pointAssumptions = engineSimplify[assumptions /. point, True];
    pointActiveK = Select[wavevector, ! FreeQ[pointMatrix, #] &];
    pointActiveCoefficients = Select[coefficients, ! FreeQ[pointMatrix, #] &];
    pointSpectrum = computeSpectrumAndModes[pointMatrix, coefficients, wavevector,
      pointAssumptions, package, dimension, scope, True, False, False, {},
      pointActiveK, pointActiveCoefficients];

    restrictedJacobian = Quiet[genericRootJacobian /. point];
    emitCell[package, dimension,
      scope <> "POINT_EVIDENCE_ROOT_COEFFICIENT_JACOBIAN_RESTRICTED",
      restrictedJacobian];
    emitCell[package, dimension,
      scope <> "ROOT_COEFFICIENT_JACOBIAN_RECOMPUTED",
      failureJacobianPayload[componentSpectrum["Roots"], coefficients,
        stratum["Equations"], point]];
    ClearSystemCache[],
    {stratumIndex, Length[strata]}];
  strata
];

closureRankFromMatrix[matrix_List, assumptions_] := Module[
  {rowCount, columnCount, possibleRanks, realisedRanks},
  rowCount = Length[matrix];
  columnCount = If[rowCount == 0, 0, Length[First[matrix]]];
  possibleRanks = Range[Min[rowCount, columnCount]];
  realisedRanks = Select[possibleRanks,
    Function[rank,
      AnyTrue[allMaximalMinors[matrix, rank],
        ! TrueQ[engineSimplify[# == 0, assumptions]] &]]];
  Max[Prepend[realisedRanks, 0]]
];

emitQ11[spectrum_, coefficients_List, wavevector_List, amplitudes_List,
    assumptions_, package_String, dimension_Integer] := Module[
  {bulkAssumptions, bulkFieldRecord, bulkDispersion, kwObjects, root,
   kwEquation, kwSolutionDecision, kwSolutions, kwExpression,
   closureSourceEquations,
   closureEquations, closureUnknowns, closureMatrix, closureRank},
  bulkAssumptions = And[assumptions, Element[A, Reals], cs0 > 0];
  bulkFieldRecord = <|
    "Amplitude" -> A,
    "FieldEquation" -> (bulkPhi[Sequence @@ wavevector, w, t] ==
      A Cos[Total[MapThread[Times, {wavevector,
          Table[Symbol["x" <> ToString[index]], {index, dimension}]}]] +
        kw w - omegaLinear t]),
    "Dispersion" -> (omegaSquared == cs0^2 (Total[wavevector^2] + kwSquared))|>;
  bulkDispersion = bulkFieldRecord["Dispersion"];
  kwObjects = Table[
    root = spectrum["Roots"][[rootIndex]];
    kwEquation = bulkDispersion /. omegaSquared -> root;
    emitCell[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_KW_EQUATION", kwEquation];
    kwSolutionDecision = boundedSolveRoute[{kwEquation}, {kwSquared}];
    kwSolutions = kwSolutionDecision["OUTCOME"];
    kwExpression = If[ListQ[kwSolutions] && kwSolutions =!= {},
      kwSquared /. First[kwSolutions],
      Failure["UnsolvedBulkNormalWavevector", <|
        "Equation" -> kwEquation, "SolverResult" -> kwSolutions|>]];
    emitCell[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_KW_SQUARED", kwExpression];
    emitCell[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_KW_SIGN",
      signPayload[kwExpression, bulkAssumptions]];
    emitLocus[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_KW_ZERO_LOCUS",
      {kwExpression == 0}, Join[coefficients, {cs0}], bulkAssumptions];
    kwExpression,
    {rootIndex, Length[spectrum["Roots"]]}];

  closureSourceEquations = Join[
    Table[braneField[component] == amplitudes[[component]] Cos[phaseVariable],
      {component, dimension}],
    {bulkFieldRecord["FieldEquation"], bulkFieldRecord["Dispersion"]}];
  closureEquations = Select[closureSourceEquations,
    Function[equation,
      ! FreeQ[equation, bulkFieldRecord["Amplitude"]] &&
        AnyTrue[amplitudes, ! FreeQ[equation, #] &]]];
  closureUnknowns = Join[amplitudes, {bulkFieldRecord["Amplitude"]}];
  closureMatrix = Table[
    Coefficient[relationResidual[equation], unknown],
    {equation, closureEquations}, {unknown, closureUnknowns}];
  closureRank = closureRankFromMatrix[closureMatrix, bulkAssumptions];
  emitCell[package, dimension, "C1_EQUATIONS", closureEquations];
  emitCell[package, dimension, "C2_UNKNOWNS", closureUnknowns];
  emitCell[package, dimension, "C2_COUNT", Length[closureUnknowns]];
  emitCell[package, dimension, "C3_RANK", closureRank];
  emitCell[package, dimension, "C4_DIFFERENCE",
    Length[closureUnknowns] - closureRank];
  kwObjects
];

runCell[package_String, dimension_Integer, invariantData_] := Module[
  {frame, spaceCoordinates, timeCoordinate, fields, coordinateGradient,
   gradientVariables, gradientJet, velocityJet, bareFieldJet, amplitudes,
   wavevector, phase, premises, assumptions, bulkAssumptions,
   pdJet, pdCoordinate, densityJet, densityCoordinate, kineticRecordList,
   stiffnessRecordList, jetRules, kineticTermsJet, kineticTermsCoordinate,
   stiffnessTermsJet, stiffnessTermsCoordinate, stiffnessFunctional,
   lagrangianJet, lagrangianCoordinate, eulerExpressions, eulerSystem,
   ansatzRules, planeEuler, strippedFactor, amplitudeEquations, matrixA,
   planeGradientRules, planeVelocityRules, planeLagrangian,
   averagedLagrangian, matrixB, matrixResidual, routeSelection,
   downstreamMatrix, coefficientOrdering, matrixCoefficientJacobian,
   actionRecords, dimensionData, spectrum, rootDimensionObjects,
   scaledObjects, genericRootJacobian, strata, q7Residual, kwObjects,
   derivedHomogeneity, independentGradient},
  frame = coordinateFrame[dimension];
  spaceCoordinates = frame["X"];
  timeCoordinate = frame["T"];
  fields = frame["Fields"];
  coordinateGradient = frame["Gradient"];
  gradientVariables = invariantData["GVariables"];
  gradientJet = Partition[gradientVariables, dimension];
  velocityJet = Table[Symbol["v" <> ToString[index]], {index, dimension}];
  bareFieldJet = Table[Symbol["uBare" <> ToString[index]], {index, dimension}];
  amplitudes = Table[Symbol["a" <> ToString[index]], {index, dimension}];
  wavevector = Table[Symbol["k" <> ToString[index]], {index, dimension}];
  phase = Total[MapThread[Times, {wavevector, spaceCoordinates}]] -
    omegaLinear timeCoordinate;

  premises = makePremises[package, dimension, wavevector, amplitudes];
  assumptions = premises["AtDimension"];
  bulkAssumptions = And[assumptions, Element[A, Reals], cs0 > 0];
  emitLocalCell[package, dimension, "PREMISE_INVENTORY",
    premiseInventory[premises, package, dimension, amplitudes]];

  pdJet = invariantData["PDPolynomial"];
  pdCoordinate = pdJet /. Thread[gradientVariables -> Flatten[coordinateGradient]];
  emitCell[package, dimension, "PD_TERM", Expand[pdCoordinate]];
  densityJet = <|
    "curl" -> curlDensity[gradientJet],
    "div" -> divDensity[gradientJet],
    "symtl" -> symtlDensity[gradientJet],
    "pd" -> pdJet|>;
  densityCoordinate = <|
    "curl" -> curlDensity[coordinateGradient],
    "div" -> divDensity[coordinateGradient],
    "symtl" -> symtlDensity[coordinateGradient],
    "pd" -> pdCoordinate|>;
  kineticRecordList = kineticRecords[package, velocityJet];
  stiffnessRecordList = stiffnessRecords[package, densityJet, densityCoordinate];
  jetRules = Join[
    Thread[velocityJet -> (D[#, timeCoordinate] & /@ fields)],
    Thread[gradientVariables -> Flatten[coordinateGradient]],
    Thread[bareFieldJet -> fields]];
  kineticTermsJet = (#["Factor"] #["DensityJet"]) & /@ kineticRecordList;
  kineticTermsCoordinate = kineticTermsJet /. jetRules;
  stiffnessTermsJet = (#["Factor"] #["DensityJet"]) & /@ stiffnessRecordList;
  stiffnessTermsCoordinate = (#["Factor"] #["DensityCoordinate"]) & /@
    stiffnessRecordList;
  stiffnessFunctional = Total[stiffnessTermsCoordinate];
  lagrangianJet = Total[kineticTermsJet] - Total[stiffnessTermsJet];
  lagrangianCoordinate = Expand[lagrangianJet /. jetRules];
  emitCell[package, dimension, "LAGRANGIAN", lagrangianCoordinate];
  emitCell[package, dimension, "KINETIC_TERMS", kineticTermsCoordinate];
  emitCell[package, dimension, "STIFFNESS_TERMS", stiffnessTermsCoordinate];

  eulerExpressions = Table[Expand[
      D[D[lagrangianJet, velocityJet[[component]]] /. jetRules,
        timeCoordinate] +
      Total[Table[
        D[D[lagrangianJet, gradientJet[[row, component]]] /. jetRules,
          spaceCoordinates[[row]]],
        {row, dimension}]] -
      (D[lagrangianJet, bareFieldJet[[component]]] /. jetRules)],
    {component, dimension}];
  eulerSystem = (# == 0) & /@ eulerExpressions;
  emitCell[package, dimension, "EULER_LAGRANGE_SYSTEM", eulerSystem];

  ansatzRules = Table[With[
      {head = frame["Heads"][[component]],
       amplitude = amplitudes[[component]],
       arguments = frame["Arguments"], phaseExpression = phase},
      head -> Function[Evaluate[arguments],
        Evaluate[amplitude Cos[phaseExpression]]]],
    {component, dimension}];
  planeEuler = TrigFactor[eulerExpressions /. ansatzRules] /.
    omegaLinear^2 -> omegaSquared;
  strippedFactor = routeAStrippedFactor[planeEuler, amplitudes,
    Join[spaceCoordinates, {timeCoordinate}]];
  If[MissingQ[strippedFactor],
    Throw[Failure["RouteAStrippedFactorUnavailable", <|
      "PlaneEulerExpressions" -> planeEuler|>], operationalFailure]];
  amplitudeEquations = engineSimplify[#/strippedFactor, assumptions] & /@
    planeEuler;
  matrixA = Table[engineSimplify[
      Coefficient[amplitudeEquations[[row]], amplitudes[[column]]], assumptions],
    {row, dimension}, {column, dimension}];
  emitCell[package, dimension, "M_ROUTE_A_STRIPPED_FACTOR", strippedFactor];
  emitCell[package, dimension, "M_A", matrixA];

  planeGradientRules = Thread[gradientVariables -> Flatten[Table[
      D[amplitudes[[column]] Cos[phaseVariable], phaseVariable] wavevector[[row]],
      {row, dimension}, {column, dimension}]]];
  planeVelocityRules = Thread[velocityJet -> Table[
      D[amplitudes[[component]] Cos[phaseVariable], phaseVariable] (-omegaLinear),
      {component, dimension}]];
  planeLagrangian = lagrangianJet /.
    Join[planeGradientRules, planeVelocityRules];
  averagedLagrangian = engineSimplify[
    Integrate[Expand[planeLagrangian], {phaseVariable, 0, 2 Pi}]/(2 Pi) /.
      omegaLinear^2 -> omegaSquared, assumptions];
  matrixB = Table[engineSimplify[
      D[averagedLagrangian, amplitudes[[row]], amplitudes[[column]]],
      assumptions],
    {row, dimension}, {column, dimension}];
  emitCell[package, dimension, "M_B", matrixB];
  matrixResidual = Map[engineSimplify[#, assumptions] &, matrixA - matrixB, {2}];
  emitCell[package, dimension, "M_RESIDUAL", matrixResidual];
  emitCell[package, dimension, "M_RATIO",
    engineSimplify[matrixA[[1, 1]]/matrixB[[1, 1]], assumptions]];
  emitCell[package, dimension, "M_ROUTE_RESIDUAL_SCOPE",
    "CODING_CONSISTENCY_ONLY"];
  routeSelection = <|"TOKEN" -> "M_B", "MATRIX" -> matrixB|>;
  downstreamMatrix = routeSelection["MATRIX"];
  emitCell[package, dimension, "M_ROUTE_USED", routeSelection["TOKEN"]];

  coefficientOrdering = coefficientOrderingFromRecords[
    kineticRecordList, stiffnessRecordList];
  emitCell[package, dimension, "COEFFICIENT_ORDERING", coefficientOrdering];
  matrixCoefficientJacobian = Table[
    Map[engineSimplify[#, assumptions] &,
      D[downstreamMatrix, coefficient], {2}],
    {coefficient, coefficientOrdering}];
  emitCell[package, dimension, "M_COEFFICIENT_JACOBIAN",
    matrixCoefficientJacobian];

  actionRecords = Join[kineticRecordList,
    Map[Append[#, "Factor" -> -#["Factor"]] &, stiffnessRecordList]];
  dimensionData = buildDimensions[coefficientOrdering, actionRecords,
    velocityJet, gradientVariables, amplitudes, wavevector, assumptions,
    package, dimension];

  spectrum = computeSpectrumAndModes[downstreamMatrix, coefficientOrdering,
    wavevector, assumptions, package, dimension, "", False, True, False, {},
    wavevector, coefficientOrdering];
  rootDimensionObjects = Table[
    dimensionOfScalar[spectrum["Roots"][[rootIndex]]/Total[wavevector^2],
      dimensionData["AtomDimensions"], assumptions],
    {rootIndex, Length[spectrum["Roots"]]}];
  Do[emitCell[package, dimension,
      "ROOT" <> ToString[rootIndex] <> "_DIM_OVER_KSQ",
      rootDimensionObjects[[rootIndex]]],
    {rootIndex, Length[rootDimensionObjects]}];
  emitScaledRoots[spectrum, wavevector, assumptions, package, dimension];
  genericRootJacobian = Table[
    engineSimplify[D[spectrum["Roots"][[rootIndex]], coefficient], assumptions],
    {rootIndex, Length[spectrum["Roots"]]},
    {coefficient, coefficientOrdering}];
  emitCell[package, dimension, "ROOT_COEFFICIENT_JACOBIAN",
    genericRootJacobian];

  q7Residual = If[dimension == 3,
    independentGradient = Partition[invariantData["GVariables"], dimension];
    emitQ7[stiffnessRecordList, coordinateGradient, independentGradient,
      package, dimension],
    tokenNotApplicable];

  kwObjects = emitQ11[spectrum, coefficientOrdering, wavevector, amplitudes,
    assumptions, package, dimension];

  derivedHomogeneity = Join[
    {homogeneityRecord["DET_M", spectrum["Determinant"],
      dimensionData["AtomDimensions"], assumptions]},
    Table[homogeneityRecord["ROOT" <> ToString[rootIndex] <> "_VALUE",
      spectrum["Roots"][[rootIndex]], dimensionData["AtomDimensions"],
      assumptions], {rootIndex, Length[spectrum["Roots"]]}],
    Table[homogeneityRecord["ROOT" <> ToString[rootIndex] <> "_N5_M_DOT_K",
      spectrum["Q4Derived"][[rootIndex]]["MDotK"],
      dimensionData["AtomDimensions"], assumptions],
      {rootIndex, Length[spectrum["Q4Derived"]]}],
    Table[homogeneityRecord["ROOT" <> ToString[rootIndex] <> "_N6_RESIDUAL",
      spectrum["Q4Derived"][[rootIndex]]["BasisResiduals"],
      dimensionData["AtomDimensions"], assumptions],
      {rootIndex, Length[spectrum["Q4Derived"]]}],
    If[dimension == 3,
      {homogeneityRecord["Q7_RESIDUAL", q7Residual,
        dimensionData["AtomDimensions"], assumptions]}, {}],
    Table[homogeneityRecord["ROOT" <> ToString[rootIndex] <> "_KW_SQUARED",
      kwObjects[[rootIndex]], dimensionData["AtomDimensions"], bulkAssumptions],
      {rootIndex, Length[kwObjects]}]
  ];
  emitCell[package, dimension, "DIM_HOMOGENEITY_DERIVED", derivedHomogeneity];

  strata = emitStrata[spectrum["Candidates"], downstreamMatrix,
    genericRootJacobian, coefficientOrdering, wavevector, assumptions,
    package, dimension];
];

packageOrder = {
  "MAIN", "XFORM_CURLONLY", "XFORM_EXTRA", "XFORM_DIVONLY",
  "XFORM_TRACELESS", "XCOEF_BSCALE", "XCOEF_BSIGN", "XKIN_ANISO"};
declaredSweep = <|
  "MAIN" -> {2, 3, 4, 5},
  "XFORM_CURLONLY" -> {2, 3, 4, 5},
  "XFORM_EXTRA" -> {2, 3, 4, 5},
  "XFORM_DIVONLY" -> {3, 4},
  "XFORM_TRACELESS" -> {3, 4},
  "XCOEF_BSCALE" -> {3},
  "XCOEF_BSIGN" -> {3},
  "XKIN_ANISO" -> {2, 3, 4}|>;
sweepDimensions = Sort[DeleteDuplicates[Flatten[Values[declaredSweep]]]];
declaredPairs = Reap[
    Do[If[MemberQ[declaredSweep[package], dimension],
      Sow[{package, dimension}]],
      {dimension, sweepDimensions}, {package, packageOrder}]][[2, 1]];

scriptArguments = Rest[$ScriptCommandLine];
selectedPairs = Which[
  scriptArguments === {}, declaredPairs,
  Length[scriptArguments] == 2 && MemberQ[packageOrder, First[scriptArguments]] &&
      StringMatchQ[Last[scriptArguments], DigitCharacter ..],
    selectedDimension = FromDigits[Last[scriptArguments]];
    If[MemberQ[declaredSweep[First[scriptArguments]], selectedDimension],
      {{First[scriptArguments], selectedDimension}}, Quit[64]],
  True, Quit[64]
];

runPairs = {};
invariantCache = <||>;
operationalResult = Catch[
  Do[
    package = pair[[1]];
    dimension = pair[[2]];
    If[! KeyExistsQ[invariantCache, dimension],
      invariant = buildInvariantCensus[dimension, package];
      AssociateTo[invariantCache, dimension -> invariant],
      invariant = invariantCache[dimension];
      emitInvariantCensus[invariant, package, dimension]
    ];
    runCell[package, dimension, invariant];
    AppendTo[runPairs, {package, dimension}],
    {pair, selectedPairs}];
  completedNormally,
  operationalFailure
];

If[Head[operationalResult] === Failure,
  WriteString[First[$Output], "OPERATIONAL_FAILURE: " <>
    ToString[operationalResult, InputForm, PageWidth -> Infinity] <> "\n"];
  Flush[First[$Output]];
  Quit[70]
];
emit[runEmission["RUN_PAIRS"], runPairs];
emit[runEmission["SKIPPED_PAIRS"], Complement[declaredPairs, runPairs]];
localInventoryName = standardEmissionName[localInventoryEmission[]];
emit[localInventoryEmission[], Append[localNames, localInventoryName]];
