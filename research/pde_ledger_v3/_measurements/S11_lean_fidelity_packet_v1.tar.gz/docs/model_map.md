# The Model Map — one-medium analog, derivation atlas + conceptual throughline

> ⚠ **CURRENT FRONT (2026-07-31): `research/pde_ledger_v3/`** — start at `NEXT_SESSION.md`.
> ⛔ The dimension rewrite named below is **not** the current front. {#current-front}


**What this is.** The single high-level map of the whole toy model: the conceptual picture, every earned derivation with a one-line note + pointer to the full doc/scripts, the honest ledger of what is *predicted* vs *calibrated* vs *unresolved (R1)* vs *departure*, and a glossary. Read this to hold the model in your head; read the cited sources to act on any specific number.

> ⛔ **SUPERSEDED 2026-07-31 — kept as history, ⛔ not as an instruction. The current front is the banner at the top of this file (`docs/model_map.md#current-front`): v3, `research/pde_ledger_v3/NEXT_SESSION.md`.** ⏸ **CURRENT FRONT (2026-07-27) — NOT stage 045.** The ledger build is PAUSED behind the **dimension
> rewrite** (all 30 dimension-bearing SymPy audit scripts onto one shared module; **6 done** — 004,
> 011, 012, 013, 016, 018, all waiver-free; ▶ NEXT = stage023 `.py` (step f), then 027/021).
> Read `research/pde_ledger_v2/manifests/DIMENSION_REWRITE.md`, and `STATUS.md` for the front.
> Every "▶ NEXT = stage 045" below is the *ledger-build* next, correct in its own sequence but not the
> current action. Also paused: **stage 044-v2** (the dynamical-Σ un-freeze), which precedes 045.
>
> **This is a synthesis map, not the source of truth.** Assembled 2026-07-21 from a six-agent sector fan-out over the committed repo. For any discrepancy the **cited source files are authoritative** — the sector reports under `software/stage1_solver/reports/` and `software/em_charge_attribute/`, the v2-ledger stages under `research/pde_ledger_v2/notes/stages/`, the blueprint `notes/ledger_v2_blueprint.md`, the trackers `research/pde_ledger_v2/notes/{parameter_register,midway_knob_audit}.md`, and the resume doc `research/pde_ledger_v2/notes/RESUME_ROADMAP.md`. Re-read those before trusting any claim here.
>
> **Framing.** This is a *toy analog*: the goal is ONE self-consistent structure (a calibrated PDE) that reproduces GR-like and EM-like far-field behavior — a working math **bridge**, not an ontology claim. A result that **breaks** the concept is welcome and first-class. Magnitudes are calibrated; **among observational predictions**, only held-out **dimensionless** structure tests the model. ⚠ That is one falsification route, ⛔ **not the whole standard** — the governing standard (which also counts internal impossibility and treats surplus over an incomplete reference theory as expected) is `research/pde_ledger_v3/CHARTER.md#falsification-standard`; read it there, ⛔ not from this line. A clean "it all works" is suspicious.

---

## 1. The model in one picture (the throughline)

Everything bottoms out in **ONE compressible superfluid** — a Gross–Pitaevskii / nonlinear-Schrödinger (GNLS) condensate in a 4D bulk, order parameter `ψ`, number density `ρ=|ψ|²`, closed by a stiff polytropic equation of state `P=Kρ⁵` (postulated closure).

That one medium exists in **two material states**, distinguished by an order field `χ_B∈[0,1]`: {#two-material-states}
- **the brane** (`χ_B=1`) — the ordered, *shear-supporting* phase; our 3D space is a domain-wall brane at `w=0` in the 4D bulk;
- **the bulk** (`χ_B=0`) — the SAME medium, de-structured and *shear-free*.

⚠ This two-phase split is **POSTULATED, not derived** — the brane comes from `V_χ(r_B)`, a **postulated potential on the order field**, so it does not *emerge* from the one medium; it is put in by hand (see §3.1). ⛔ The reason is **not** that the parent `U(ρ)` is single-well — `U(ρ)` is a potential on a *different* field, so its shape decides nothing here (S1, `research/pde_ledger_v3/V3_STEP_PLAN.md`). Read the throughline below as the *intended architecture*, with the honest earned-vs-postulated status in §3–§4.

A **particle is a defect** — a topological **throat** that punctures the brane into `±w` (a phase-conversion site / open channel, not a suction force). "Defect", "throat", "puncture" — never "dent" (a dent doesn't puncture).

The four forces are **modes of the one medium**, not four theories bolted together:

| Force | Native mechanism | Carrier / cone |
|---|---|---|
| **Gravity** | the **drain/flow** between defects — each throat removes number-flux, two drains sit in each other's inflow → attraction (`1/r²` on the brane, `1/R³` in the bulk). NOT a ripple. ⛔ The `1/r²` exponent and the attractive sign are **CONDITIONAL pending the S14a drain bridge, NOT earned** — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`. | density mode, `c_s` |
| **Light** | in-plane **MacCullagh shear** of the brane (energy in `curl u`, on the brane so it leaves the bulk/throat undisturbed) → two transverse photons | brane shear `u_T`, `c_γ` |
| **Charge** | the **static ±w throat**: the puncture bends the brane into `±w`; the charge **sign = the ±w orientation** (Z₂-topological, NOT additive) | electric scalar `h`, `c_E` ⚠ |
| **Magnetism** | the **moving ±w throat** — the electric twin; a moving signed throat shears the brane through the *same* transverse sector as light | brane shear `u_T`, `c_γ` |

⚠ `c_E` has **no committed lock** to `c_γ` (`c_s/c_E=2` was chosen to *avoid* forcing one) — do NOT read the table as asserting `c_E=c_γ`; that equality is the open `r_cone` question (§2, §3.6). And gravity's drain/return is **non-variational** (a source/BC, not a Lagrangian term) — which is why the unified structure is a *synthesis*, not a sum (§2).

The unifying test is **boost-consistency / emergent Lorentz**: does *one* calibration make the electric and magnetic sectors two faces of one interaction? The magnetism sector is built precisely to probe this.

**Honest status in one breath:** all four far-field sectors now exist on one shared field set. Gravity is the most complete (form + fingerprints earned, magnitudes calibrated, one held-out falsifiable departure). Light earns two transverse photons but leaves a characterized stray-longitudinal departure. Charge and magnetism earn the *structure* (mechanism, falloff, tensor form) target-blind, but the electric **sign** — and with it the magnetic sign — is genuinely **unresolved (R1)**, waiting on a sim-deferred nonlinear throat solve. The model is a coherent, calibratable single-medium analog with a real, un-papered-over honesty ledger. ⛔ Gravity's "form … earned" and its "one held-out falsifiable departure" name the `1/r²` law, the attractive sign and the stage009 `RETURN_RESIDUAL_PREDICTION` residual — all three are **CONDITIONAL pending the S14a drain bridge, NOT earned** (the fingerprints are unaffected) — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`.

---

## 2. The shared substrate (fields, speeds, and why it is NOT a sum)

**Primitive constants of the medium (~4 declared universal):** `ħ` `[ML²T⁻¹]`, `m_GNLS` `[M]`, `K` `[ML¹⁸T⁻²]`, `ρ0` `[L⁻⁴]`.

**Shared field set:** `{ρ, θ, r_B, H/h, u_L, u_T}`
- `ρ=|ψ|²` — 4D number density `[L⁻⁴]`; `ρ0` = asymptotic datum. (In the two-phase writeup `n`, with `n_B=χ_B n` the ordered fraction.)
- `θ` — condensate phase (dimensionless); flow `v_b=(ħ/m)∇θ`.
- `χ_B` — two-phase order field `∈[0,1]`, brane=1/bulk=0; **independent scalar, explicitly NOT `|P_∥|²`**.
- `r_B / ρ_B` — wall (brane) amplitude / projected on-brane density `[L⁻⁴]` (`ρ_B=∫W χ_B n dw`); `ρ_br` = brane mass density `[ML⁻³]`.
- `H / h` — electric scalar; `H` parent `[L⁻¹]` localized by a Pöschl–Teller operator, `h=P₀H` its one gapless zero mode; embedding identity `ξ_w=ℓh`.
- `u_L` — longitudinal brane displacement (the light sector's stray mode).
- `u_T` — transverse brane displacement `∇·u_T=0` (the two photons; reused by magnetism).
- `P` — polar orientation field ("little arrows") — **RETIRED as an independent field by Decision 16** (see §6); survives only as the head≠tail `+w≠−w` polarity migrated to the throat sleeve.

**The three (+1) speeds — state carefully:**
- `c_s² = 5Kρ⁴/m` — phonon / density / **gravity-change** speed; DERIVED from the EOS (factor 5 from `dP/dρ`); `d ln c_s/d ln ρ=2`.
- `c_γ² = μ_R/ρ_br` — **light cone**, MacCullagh shear modulus over brane inertia; **SHARED by magnetism**.
- `c_E` — electric speed, `K_h=M_h c_E²`; **NO committed cone lock** (`c_s/c_E=2` was *chosen* to avoid forcing one).
- `v_b=(ħ/m)∇θ` — condensate flow. And `c=c_γ` is the wave-sector ceiling (earned from wave kinematics, NOT from `E=mc²`).
- ⚠ `λ_γ=c_γ/c_s` is a **DERIVED ratio, NOT a free knob** — the free-unreduced content is `c_γ`, ultimately `{μ_R, ρ_br}`. The `c_±²=(3±√2)/2` witness values are a G0 witness point in `c_E=1` units, **not** universal cones; there is no `c_L²=B_eff/ρ_br` "lock pair" (the scalar-block inertia is `A_eff=ρ_br+C_J²/κ_phase`).

**Why the unified structure is NOT an additive sum.** The four sectors share ONE field set, but Part VII must **synthesize**, not write `(medium)+(gravity)+(light)+(charge)+(magnetism)`:
- **gravity's drain/return is NON-variational** — carried as source / boundary-condition bookkeeping, not a Lagrangian term;
- the G0 card's `r_B` wall action must be **reconciled/de-duplicated** with Part I's `χ_B` wall action (compounded by the pending Decision-16 retirement).

---

## 3. The derivation atlas

Status tokens: **EARNED** (target-blind, within stated postulates) · **CALIBRATED** (magnitude tuned to an external anchor) · **R1_REQUIRED(x)** (unresolved, needs the named closure — usually the throat solve) · **DEPARTURE** (a characterized, first-class break from the reference theory) · **SIM-DEFERRED** · **cite-only** · **SUPERSEDED**.

### 3.1 Medium — Part I ✅ built (stages 004–007), tri-reviewed

*Lays the shared substrate; earns no force sector by itself. The brane/two-phase split is POSTULATED, not derived from the one medium.*

- **stage 004** — GNLS parent action + dimensional foundation. **EARNED (dim foundation).** Fixes `{L,T,M}` base + field dictionary (17 checks); mass is an explicit constant (not emergent). `[ψ]=L⁻²`, `[K]=ML¹⁸T⁻²`; `ξ_h=√2ħ/(mc_s0)`; `h0=mc_s0²/4`. → `research/pde_ledger_v2/notes/stages/ledger_stage004_gnls_action_dimensional_foundation.md` (+ `scripts/…_sympy_audit.py`, `mathematica/…_mathematica_audit.wl`). *Open:* parent action & `m_GNLS` POSTULATED; `m_defect` NOT emergent (`INFLOW_MASS_SOURCE_MISSING`).
- **stage 005** — EOS sound speed + light/sound ratio. **EARNED (within imposed EOS), CALIBRATED landing.** `c_s²=5Kρ⁴/m` (factor 5 derived); `c=c_γ` ceiling. The **free-unreduced quantity is `c_γ`** (ultimately `{μ_R,ρ_br}`); the *ratio* `λ_γ=c_γ/c_s` is DERIVED, and only the *constraint* `λ_γ=1` is a calibrated cone lock (`pathA_40`). A reversible negative control proves `c_γ` is unpinned by the parent action (`C_GAMMA_RATIO_UNDERDETERMINED`). → `…/ledger_stage005_sound_speed_light_ratio.md`. *Open:* EOS `P=Kρ⁵` IMPOSED; `c_γ` numeric undetermined; `ħ` provenance a gap.
- **stage 006** — Two-phase material-state ontology (`χ_B`). **`ACTION_SPECIFIED_CLASSIFIED` (postulated functional).** Two-phase free energy + order-balance PDE (13 pins); single-kink wall admission; recovery reduction to the old `S_leak` law (assert-zero). → `…/ledger_stage006_two_phase_chiB_ontology.md`. *Open/departure:* **whole two-phase split POSTULATED** (it comes from the postulated `V_χ(r_B)` on the *order* field; ⛔ **not** because the parent `U(ρ)` is single-well — that is a potential on a *different* field, v2's wrong argument, corrected at S1 in `research/pde_ledger_v3/V3_STEP_PLAN.md`); **θ-as-Maxwell-φ = FATAL_FLAW** (wrong-sign stiffness; Maxwell only `BY_TUNING`); slab width `W_slab` FREE-UNREDUCED. `α_aniso` **retired by Decision 16** (amendment landed 2026-07-21; stage006 operative `DRIFT(6)→DRIFT(5)`).
- **stage 007** — Shear-surface G0 freeze (frozen brane/light action). **EARNED (freeze fidelity + operative DOF=4 + dim firewall), POSTULATED/CALIBRATED landing.** Hash-guarded frozen MacCullagh shear + `u_w` gap; operative **`POST_D16_DRIFT(7)`** = 3 constants {ρ_br, μ_R, Ω_w} + `g_ℓ` + 3 postulates. `c_γ²=μ_R/ρ_br`. → `…/ledger_stage007_shear_surface_g0_freeze.md`. *Open:* `μ_R/ρ_br` Route-A reduction PENDING (R10). A polar-field `P` substructure was tried as a light-stiffness source and **retired (Decision 16)** → failures-paper backlog (a −5 route-less reduction); the historical freeze-as-run tier (DOF=8, drift 11) is retained in the audit script as verification provenance.

### 3.2 Gravity — Part II ✅ built (stages 001–002, 008–029), tri-reviewed, sector CLOSED

*Gravity = the drain/flow between defects. Calibrate-predict: form/sign/fingerprint earned target-blind; magnitudes (`G`, `54/5`, `2/5`) calibrated to a separately-audited PN corpus.* ⛔ The "form/sign" half of that — the `1/r²` exponent and the attractive sign — is **CONDITIONAL pending the S14a drain bridge, NOT earned**; only the fingerprints are unaffected — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`.

- **pathA_21c** — inter-defect force from the Noether stress tensor. **EARNED (form+sign), CALIBRATED magnitude.** Like drains **attract**; `F_12 = −(m N_∞,3 Q1Q2/4πr²) r̂` (reduced-3D `r⁻²`; bulk `R⁻³`). → `software/stage1_solver/reports/pathA_21c_force_from_noether_stress_tensor.md`; folded into ledger stages 001/002. *Open:* full sign residual (quantum/`V_conf`/Maxwell pieces not all evaluated); `G` form not derived. ⛔ The **EARNED (form+sign)** token here — the `r⁻²` exponent and the "like drains **attract**" sign — is **CONDITIONAL pending the S14a drain bridge, NOT earned**: it was derived under a Gauss **number-flux** drain, and the committed dynamical `Γ_B` law severed that chain — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`. {#pathA-21c}
- **pathA_28** — monopole/dipole radiation constraint spec. **EARNED (DtN amplitudes/orders); constraint-spec not suppression proof.** `A_raw(ℓ0)∝ω`, `(ℓ1)∝ω³`, `(ℓ2)∝ω⁵` (the `i Q2 a⁵ω⁵/27c_s⁵`). → `…/pathA_28_monopole.md`; ledger stage008. *Open:* `cancellation_possible` is a literal flag, not computed.
- **pathA_29** — flat-slab brane↔bulk return residual. ⛔ **CONDITIONAL pending the S14a drain bridge, NOT earned** — the **held-out FALSIFIABLE PREDICTION** claim (`RETURN_RESIDUAL_PREDICTION`) is suspended, neither carried nor discarded. A finite return leaves a bounded, lower-order ℓ=0/1 `c_s`-radiation residual: **`1−T_ℓ(0)=ε_ℓ/(1+ε_ℓ)`**, orders `p_res=1,3` — the departure from GR (which forbids ℓ=0/1). Localization: `p=2` (1/r² survives the slab) vs anti-localizing warp `RETURN_NOGO` (able-to-fail). → `…/pathA_29_brane_bulk_return.md`; ledger stages 009/010. *Open:* slab geometry POSTULATED; `ε_ℓ` FREE-UNREDUCED; full closure = Gate-6. ⛔ Do not cite as earned until the S14a bridge succeeds — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`.
- **pathA_30–34** — moving-throat reduced-closure Gates 1–5. Gate1 DtN unit test (`DN_UNITTEST_BC_DEPENDENT`); Gate2 breathing mode (`BREATHING_CALIBRATED`); Gate3 SO(3)/ℓ=2 isotropy — EARNED slice (`−Δ_S²Y_2m=6Y_2m`, lane defects=0) + **`ISOTROPY_CALIBRATED`** landing (`{T_Ω,β₂}` calibrated pending R36); **Gate4** ℓ=2 quadrupole fingerprint — **EARNED:** `Ŷ₂ᵒᵘᵗ=1+z²/9+4z⁴/81+i z⁵/27+…`, **χ_Q=+1** outgoing; Gate5 cross-ℓ **honest NEGATIVE** (`FAIL_UNDERDETERMINED_NOT_PREDICTIVE` → `CROSS_L_RESIDUAL_PREDICTION`: the linear model does NOT pin the ℓ=0/1 return magnitude; needs a Gate-6 selector). The earned **cross-ℓ radiation fingerprint** is `{1, 1/2, 1/27}` at `{ω¹, ω³, ω⁵}` (the ℓ=0/1/2 leading amplitudes). → reports `pathA_3{0,1,2,3,4}_*.md`; ledger stages 011–023. 
- **pathA_43** — density-mode ℓ=2 quadrupole radiative port. **`DENSITY_PORT_HOSTED`.** Builds the ℓ=2 port natively on the density/`c_s` mode as a two-port over (`q2` wall, `Φ2` bulk) — **retires the old `A_w` vector scaffold**; vector-freedom + `a⁻⁵` + outgoing sign `+i z⁵/27` pass. → `…/pathA_43_density_quadrupole_port.md`; ledger stages 024–027. *Open:* moment/coefficient values SIM-DEFERRED; `G`, `54/5`, `2/5` CALIBRATED.
- **pathA_2.5PN matchback** — Burke–Thorne consistency cap. **`MATCHBACK_CONSISTENT` (CALIBRATED).** Density-port moments reproduce `Γ̄₅=2G/(5c⁵)` and `K̄4K̄0=4K̄2²`; the `/27` is the earned fingerprint. → ledger stage028. 
- **PN corpus (1PN→4PN + 2.5PN)** — **cite-only.** Seven Zenodo-DOI'd, separately-audited, GR-matched papers; `G=GENUINE_BLOCKED`; cited not re-derived. → ledger stage029; dirs `research/1pn_orbital_dynamics`, `research/4d_{1pn_bridge,1pn_full,2pn,2_5pn,3pn,4pn}`.

**Gravity's held-out surplus:** the bounded ℓ=0/1 `ε_ℓ/(1+ε_ℓ)` residual (THE falsifier — GR/Birkhoff forbid it), the ℓ=2 rational fingerprint `1/9,4/81,1/27` + `χ_Q=+1`, the cross-ℓ fingerprint `{1, 1/2, 1/27}` at `{ω¹,ω³,ω⁵}`. **NOT held-out (calibrated/external):** `G`, `54/5`, `2/5`, force-norm, and the Gate-2/3 wall packet `{μ_η,T_w,β,Vp0/ℓ_c,T_Ω,β₂}`. ⛔ The first member of that surplus — the bounded ℓ=0/1 `ε_ℓ/(1+ε_ℓ)` residual, i.e. the stage009 `RETURN_RESIDUAL_PREDICTION` falsifier (GR/Birkhoff forbid it) — is **CONDITIONAL pending the S14a drain bridge, NOT earned**; the ℓ=2 rational fingerprint, `χ_Q=+1` and the cross-ℓ fingerprint are unaffected — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`.

### 3.3 Light — Part III ✅ DONE = stage003 (re-scoped 2026-07-22, surviving-solution rule)

*Light = in-plane MacCullagh shear of the brane; two transverse photons. The shared transverse sector — it establishes the `u_T`/`c_γ` foundation magnetism reuses. Under the surviving-solution rule Part III is stage003 alone; the `pathA_35` couple-stress no-go (retired-`P` post-mortem) → failures-paper backlog.*

⭐⭐ **v3 RE-DERIVED THIS SECTOR FORWARD (2026-08-02) — S9/S10/S11, and it says more than stage003 did.**
⇒ `research/pde_ledger_v3/steps/` · ⛔ read `S11_stray_longitudinal.md` before citing the stray mode.
- ⭐ **Two polarisations is a statement that our space is 3-dimensional.** The count is `D_brane − 1`,
  **computed** as a nullity in both engines; ⛔⛔ the **bulk never enters**, so codimension is not the
  wrong number, it is an **absent quantity**.
- ⭐ **Sector separation is a `D=3` fact, ⛔ not a structural one** — at `D=2` a reflection-odd invariant
  exists whose EL operator is non-zero, so compression and light *can* mix there.
- ⭐⭐ **The stray mode's ENTIRE physical status — radiative, observable, Lorentz-breaking, or none —
  reduces to ONE unbuilt object: the brane–bulk interface coupling law** (`V3_STEP_PLAN.md#s11b`). It is
  **LINEAR**, so it is half-one work that was deferred by choice.
- ⛔⛔ **`c_L` is NOT a gravitational wave** (`DEFECT_REGISTER.md#c13`) and ⛔ `u_L` is **not** `±w`.
- ⭐ **A second cone is a departure only if matter COUPLES to it.** Matter here is built from the
  transverse modes, whose wave equation is Lorentz-invariant with invariant speed `c_γ` automatically.
- ⭐⭐ **Photon stability over cosmological distance is a CONSEQUENCE of bulk shear-freeness** — light can
  only lose energy into a mode that exists to receive it, and the bulk has no transverse mode. ⇒ S9's
  second requirement is an observational consequence, ⛔ not bookkeeping. ⚠ Light **gravitates** (a
  co-moving disturbance) but does ⛔ **not dissipate**; the two were conflated once.
- ⚠ **Lensing sign UNCHECKED** — the naive drain reading points the wrong way
  (`DEFECT_REGISTER.md#c14`); ⛔ do not manufacture a reconciliation.

- **pathA_35 gate L** — `μ_R` is a postulated modulus; a `P`-substructure derivation was tried and failed (`FAIL_COUPLE_STRESS_NOGO`, Decision 16) → failures-paper backlog (`research/pde_ledger_v2/notes/ledger_exclusions_failures_paper_backlog.md`). Feeds `c_γ²=μ_R/ρ_br` forward. → `software/stage1_solver/reports/pathA_35_gateL_light.md` (+ freeze `pathA_35_G0_freeze.md`).
- **pathA_36** — C5 phase-potential derivation. **EARNED (2 transverse photons) + DEPARTURE.** Two massless photons at `c_γ²=μ_R/ρ_br` (`PASS_TRANSVERSE_UNDISTURBED`, able-to-fail); longitudinal half → **`FAIL_CAUCHY_STRAY_LONGITUDINAL`**: a Dirac–Bergmann **second-class** pair (one propagating stray longitudinal DOF), NOT Maxwell's first-class Gauss. Maxwell locus reachable `BY_TUNING` only. → `…/pathA_36_c5_phase_potential.md`.
- **stage 003** — transverse photons + stray longitudinal (**the surviving light sector; DONE**, dual-engine + tri-reviewed). **CHARACTERIZED-DEPARTURE.** Re-derives pathA_36 in-ledger, closing its fidelity gap (the Josephson sign `C_J=−Jρ_B0` derived in-script, not hardcoded); `μ_R` a postulated modulus. → `research/pde_ledger_v2/notes/stages/ledger_stage003_transverse_photons_stray_longitudinal.md`.

**Part III complete** = stage003 (the surviving light result). Split: `part3_light_atomic_split.md` (re-scoped, DONE). The `pathA_35` couple-stress no-go → failures-paper backlog Exclusion 1 (not a ledger stage).

### 3.4 Charge — Part IV ✅ COMPLETE (in-ledger, stages 030–033, 2026-07-22)

*Charge = the static ±w throat (puncture-deflection): the puncture bends the brane into ±w; sign = ±w orientation (Z₂). Coexists with gravity on the same brane (`internal_inconsistency=none`, computed).*

- **puncture-deflection electric-sign** — **R1_REQUIRED(bc_selection).** A ±w puncture bends the brane (`ξ_w=ℓh`), sourcing `h` via `g_χh`; the far-field two-body force `F_X=s₁s₂A_X/4πR²` is **target-blind** but its **sign is not invariant across admissible boundary-condition ensembles**: `A_V` neutral-**positive** (repel), `A_J=−m_gg(j+g)²` **negative** (attract), `A_M=m_gg(q²−g²)` **indefinite** (rides free `q/g`). So §4 fires `bc_selection`. → `software/em_charge_attribute/puncture_deflection_electric_sign_result.md` (+ `directive_…md`, `…_check.py/.wl`, independent recompute). Verified: dual-engine + 4-leg + Grok. **The sign is neither earned NOR calibrated — the formal result is R1** (the informal "calibratable sign" is a user framing, not the build's verdict).
- **G0 shared minimal closure card v0** — **DRAFT v0 POSTULATED closure.** Fixes parent physics once (bulk Madelung, wall `r_B`, localized `H`+PT zero mode, `χ↔h` coupling, `M_h/K_h/C_hu` with `C_hu²<B_eff K_h`); only the sleeve-contact operator `𝔅` varies (E2/E3). → `software/em_charge_attribute/g0_closure_card_v0.md` (+ scope). *Postdates Part I; duplicates its bulk/wall/scalar structure → Part VII must de-dup, NOT additive-merge.*
- **Superseded charge routes** (leftover-scalar `u_L`-clamp, defect/antidefect wall-healing, the old pathA_38 throat-body Coulomb anchor) → failures-paper backlog (`research/pde_ledger_v2/notes/ledger_exclusions_failures_paper_backlog.md`). {#superseded-charge-routes}
- **DEPARTURE — `NATIVE_P_NO_EMERGENT_GAUSS`:** exact U(1)/Maxwell Gauss proven **non-native** (Dirac–Bergmann second-class at quadratic order; no first-class chain). → `software/em_charge_attribute/reports/native_p_constraint_gate.md`.

**Resolving the R1:** only the sim-deferred **nonlinear throat/core solve** (`s↦h_A` boundary functional/barrier) can pin the class, force a holder, and (upside) deliver `q>g`.

### 3.5 Magnetism — Part V ✅ COMPLETE (in-ledger 034–039; built off-ledger, commit 53cf049f; ✅ 6-stage split `part5_magnetism_atomic_split.md` RATIFIED 2026-07-22 — stages 034–039; ✅ stage 034 (V-1) DONE + committed `109070da` (`TRANSVERSE_MOVE_ACTION_ROW`, EARNED action row); ✅ stage 035 (V-2) DONE + committed `b55a7a65` (`CONVECTION_LIKE_CONDITIONAL`, EARNED native source law); ✅ stage 036 (V-3) DONE + committed `df045a74` (`MAXWELL_DARWIN_REFERENCE`, EARNED reference kernel, tier-A conditional — inherits the electric `A_E` R1); ✅ stage 037 (V-4, THE SECTOR CRUX) DONE + committed `c8780f00` (`BOOST_STRUCTURAL_RELATION_HOLDS` + co-blocker `R1_REQUIRED(direct_moving_throat)`, EARNED structural relation — Route B, blind, reproduces Route A's tensor structure + falloff + velocity order ⇒ magnetism structurally IS the boost of electricity; only the ratio `r_BA` is open); ✅ stage 038 (V-5, the SEALED §4 first-match 1152-cell landing) DONE + committed `177d25d7` (`R1_REQUIRED(electric_bc_selection)` + 4 co-blockers, R1-landing — the magnetic sign/magnitude inherit the electric R1 [doubly-R1], emergent Lorentz `UNDETERMINED`); ✅ stage 039 (V-6, the FINAL Part-V stage) DONE + committed `63f28258` (`B_TIME_REVERSAL_EVEN`, CHARACTERIZED-DEPARTURE first-class — `b_T=∇×u_T` is time-reversal EVEN + axial vs Maxwell's T-odd `B`, the magnetic twin of 033's `NATIVE_P_NO_EMERGENT_GAUSS`; register R73 = DEPARTURE); **PART V COMPLETE** → NEXT = Part VI (the knit)) {#magnetism-part-v}

*Magnetism = the moving ±w throat (the electric twin). Two independent far-field derivations; their COMPARISON is the boost-consistency / emergent-Lorentz result.*

- **Q-CURRENT (native source)** — **EARNED (tensor form).** From signed-throat continuity, the source is derived **natively** — `J_T=q_T s η V` — NOT the old barred `j∝sV`. Supplies the ledger-ready action row (no pre-existing G0 row changed, `internal_inconsistency=none`): `S_{T+move}=∫[½ρ_br|u̇_T|² − ½μ_R|∇×u_T|² + q_T Σ s_i η(x−X_i)V_i·u_T]`, `∇·u_T=0`, `c_γ²=μ_R/ρ_br`, `q_T=λ_T τ_d`.
- **Q-BOOST (Route A)** — **EARNED (structural), tier-A conditional.** Boosts the electric anchor to the transverse Darwin interaction: `U_A=(s₁s₂A_E/4πR)[1−(D_V+A_V)/2c_γ²]`, kernel `(δ_ij+n_in_j)/8πR`. Inherits the electric `A_E` R1.
- **Q-DIRECT (Route B, BLIND to A)** — **R1_REQUIRED(direct_moving_throat).** Solves the moving-throat field directly (`foreign_payload=None`, independence enforced); reproduces Route A's kernel: `U_B=−s₁s₂q_T²(D_V+A_V)/8πμ_R R`. Magnitude carries the unresolved `q_T`. {#q-direct-route-b}
- **Q-COMPARE (the crux)** — **R1_REQUIRED(electric_bc_selection).** Tensor structure, `R⁻¹/R⁻²` falloff, and `O(V₁V₂)` order **AGREE target-blind**; full equality reduces to a single ratio `r_BA=q_T²/(ρ_br·A_E)` that is an **unresolved output** (needs `r_BA=1` AND cone `r_cone=1`, plus `q_T`, higher `v/c`, active-flux integrability — all open). → `software/em_charge_attribute/magnetism_moving_throat_result.md` (+ `…_check.py/.wl`). Verified: dual-engine + fresh-agent legs + GLM. The formal landing is the terminal **`R1_REQUIRED(electric_bc_selection)`** plus three explicitly-emitted co-blockers **`R1_REQUIRED(direct_moving_throat)`**, **`R1_REQUIRED(magnitude)`**, **`R1_REQUIRED(consistency)`** (informally "doubly-R1": it needs the throat solve AND the electric bc selection); the magnetic sign inherits the electric R1. {#q-compare-crux}
- **DEPARTURE — `B_TIME_REVERSAL_EVEN`:** `b_T=∇×u_T` is time-reversal **EVEN** (Maxwell `B` is T-odd), correctly axial — a concrete self-consistent prediction; magnetism requires the active-drain time-arrow `τ_d`.

**Build status (IV+V):** re-scoped onto these builds (the blueprint's pathA_38/39 scope is superseded — `pathA_39` rested on the barred `j∝sV`). **Part IV ✅ COMPLETE** (030–033); **Part V ✅ COMPLETE** (6-stage split ratified; 034 ✅ / 035 ✅ / 036 ✅ / 037 ✅ / 038 ✅ / 039 ✅ done). Both `part{4,5}_*_atomic_split.md` authored + ratified. **Part VI ✅ COMPLETE** (040/041/042). ▶ NEXT front = Part VII (integration).

### 3.6 Knit — Part VI ✅ COMPLETE (split ✅ RATIFIED 2026-07-23: 3 stages, build order **041→040→042** (NG5 first), autonomous per stage; fresh read of pathA_40/41/42 COMPLETE. ✅ stage 041 (VI-2, NG5) DONE + committed `c663d4a3` (`SECOND_MEDIUM_DRIFT(active_irreducible={rho_B0,chi_c,C_hu})` — a CHARACTERIZED incomplete-reduction: labelling-level one-medium closure, `drift_count=3`, `no_fourth_arena=True` at the labelling level; the irreducible trio ADDS to the count, `{rho_br,mu_R,c_E}` reducible-in-principle); ✅ stage 040 (VI-1, cone-lock re-adjudication) DONE + committed `1701c921` (`CONE_LOCK_CALIBRATED` — no committed cone lock, the `λ_γ=1`/`c_E=c_γ` locks are AVAILABLE calibration choices the committed model does NOT impose [both `WITNESSED`], CALIBRATED/UNCOMMITTED, `Δr=2` dim 10→8, genuinely able-to-fail [`forced_lock`→`CONE_LOCK_DERIVED`]; `r_cone=9/2≠1` open, `c_E=c_γ` NOT settled; dual-engine SymPy 28 / Mathematica 28, register R78–R80 + R7/R8 reconciled, canonical count 40→41); ✅ stage 042 (VI-3, charge-coupled scalar) DONE + committed `0961b27c` (`SCALAR_DEPARTURE_MAPPED_MAGNITUDE_SIM_GATED` — a first-class characterized DEPARTURE + SIM-DEFERRED magnitude: five reachable falsifiers, `c_E=c_γ` necessary-not-sufficient for Lorentz, `NATURALLY_HIDDEN` unreachable; dual-engine SymPy 49 / Mathematica 49, directive Codex→Grok→Codex GREEN, tri-review CLEAN ZERO remediation, register R81–R84 [R84 = the Part VI→VII synthesis handoff], canonical count 41→42). **✅ PART VI (THE KNIT) COMPLETE** (040 `1701c921` / 041 `c663d4a3` / 042 `0961b27c`): the knit verifies "one medium, all emergent" at the LABELLING/bookkeeping level — no committed cone lock (`Δr=2`), a labelling-level one-medium closure with an irreducible `{ρ_B0,χ_c,C_hu}` residue, a sim-gated scalar departure; neither "one medium proven" nor "second substance found". **▶ Part VII (integration) IN PROGRESS (043 ✅ `fda05f46`, 044 ✅ `087565b0`, 2/7; ▶ NEXT 045).** Gates needed reshape + RE-ADJUDICATION — the cone-lock is UNSUPPORTED as an earned lock: G0/magnetism don't establish `λ_γ=1`/`c_E=c_γ`, Part V left `c_E=c_γ?` open via `r_cone`; but the gate IS genuinely able-to-fail (`forced_lock`→`CONE_LOCK_DERIVED`), it reads *calibrated* because the model admits lock-violating witnesses. ⚠ The `.wl` are NOT uniformly independent (per-gate): 040 broad-independent, but 041's controls+verdict+drift+freedom and 042's verdict/adjudication are literals → the reshape must re-derive them as computed teeth, NOT a bare harness-strip. Codex→Grok design-review CLEAN after fold.) {#knit-part-vi}

*The knit VERIFIES "one medium, all emergent" instead of asserting it: shared cones? one irreducible parameter set with no smuggled second substance? does the propagating scalar stay consistent?*

- **pathA_40 — cone-lock.** **CALIBRATED-LOCK (`Δr=2`), to-RE-ADJUDICATE.** Neither Lorentz/Maxwell lock is derived on the earned ledger; both are calibrated: **(A) `λ_γ=1`** ⟺ `μ_R/ρ_br=5Kρ⁴/m`, **(B) `c_E=c_γ`** ⟺ `c_E²ρ_br=μ_R`. ⚠ The newer G0 card + magnetism build do **NOT** establish these — no committed cone lock — so Part VI must re-adjudicate. → `software/stage1_solver/reports/pathA_40_cone_lock.md`.
- **pathA_41 — NG5 second-medium drift.** **INCOMPLETE (`SECOND_MEDIUM_DRIFT`).** The one-medium claim doesn't fully close: `{ρ_B0, χ_c, C_hu}` remain irreducibly independent (unreduced brane-surface/embedding parameters — NOT a separate substance; `no_fourth_arena=True`). `{ρ_br, μ_R, c_E}` reducible-in-principle (throat solve). ⚠ `no_fourth_arena=True` is a **labelling closure** (no param needed a 4th-arena label), NOT a dynamical no-second-substance proof — the gate's `honest_caveat` concedes whether the one medium dynamically yields the brane is open. *This is where the knit's real falsification power lives — NG5 is the decisive reducibility test (all three gates are genuinely able-to-fail).* ⚠ The anti-absorption guard ALREADY EXISTS in `stage007` (`ANTI_ABSORPTION_NAMES={ρ_B0,χ_c,C_hu}` + disjointness assert); 041 does NOT add the first guard — it RE-INSTANTIATES/cross-checks it from the drift side. The `Q_E` anchor near-miss means the irreducible count is 3, else 4. → `…/pathA_41_ng5_second_medium_drift.md`. (Note: pathA_41's drift is this NG5 trio `{ρ_B0,χ_c,C_hu}` — distinct from the stage007 freeze drift (operative `POST_D16_DRIFT(7)`); two different drift concepts, anti-absorption-guarded so the trio is never absorbed into the freeze count.) {#knit-labelling-closure}
- **pathA_42 — charge-coupled scalar map.** **INCOMPLETE / SIM-GATED (`SCALAR_DEPARTURE_MAPPED_MAGNITUDE_SIM_GATED`).** The propagating `h`-scalar doesn't clearly break the model, but its break-risk magnitude is sim-gated: `h_EP` earned-safe on the decoupled floor **(mass channel only; full EP `NOT_EARNED`)**; radiation/universality/`u_L_EP`/preferred-frame all `SIM_GATED`. Sharp trade-off: `c_E→∞` non-radiating but preferred-frame; `c_E=c_γ` a real radiating extra scalar and **necessary-not-sufficient for Lorentz** (⚠ NOT "Lorentz-invariant" outright — radiation stays `SIM_GATED` without pinned `K_h`; also needs `δ_BA=0`/`r_cone=1`/closed higher orders/matched flux). → `…/pathA_42_charge_coupled_scalar.md`.

### 3.7 Integration — Part VII ⛔ **SUPERSEDED 2026-07-31 — a HISTORICAL record of the v2 ledger build, ⛔ not an instruction; the current front is v3 (`docs/model_map.md#current-front`).** It stopped at 2 of 7 stages (043 ✅, 044 ✅; 045–049 were never built and ⛔ are not to be built); ✅ RATIFIED 7-stage split (043–049) `notes/part7_integration_atomic_split.md` (per-Part gate PASSED 2026-07-23, commit `cf3a789c`; the spine 044 was SPLIT into 044+045; irreducible count REPORTED AS A RANGE; the 2 parked knob-audit decisions RESOLVED [report-the-range, R35 `DERIVED-in-form` label unchanged + bracket-contributor rider]; the genuinely-NEW synthesis — unified equation set + calibration map + dimensional firewall + permanent registers + sim hand-off + `χ_Q` characterization; ⛔ ~~autonomous mode OFF — per-stage gates; FULL new-derivation gauntlet + GLM tertiary~~ **all retired 2026-07-29/30 — see the process note under §3.7's stage list and `docs/development_pipeline.md`**). ✅ **stage 043 (VII-1, irreducible count as a RANGE) DONE + committed `fda05f46`** — continuous codimension **[40, 49]** (spread 9 = |C1|(3)+|C2|(6); base-continuous [27,36] + E_continuous 13) reported alongside a SEPARATE discrete structural-postulate count **11 (=7+4)**; the coherent debt-counting rule (count = nominal − DERIVED-and-EXECUTED − CONV − external-bridge; PENDING route-ful reduction-debt + IMPOSED calibrations STAY counted once; LOW↔HIGH only on C1/C2); the reduction-debt set counted ONCE; the Δr independence diagnostic HONESTLY scoped to blocks M+Wχ only (`CONFIRMED_IN_TESTED_M_AND_WCHI_BLOCKS`, discharges no knob); R49 field-profiles OUT-of-built-v2-scope; dual-engine SymPy 20 / Mathematica 20 both exit 0, register R85–R92 (STRUCTURAL/dimensionless). ✅ **stage 044 (VII-2a, the conservative parent action + `r_B≡χ_B` reconciliation, the heavy spine) DONE + committed `087565b0`** — verdict **`PARENT_ACTION_ASSEMBLED_AT_COMPLETENESS_FLOOR`** (`\StatusOpen`; structure/completeness-floor only, the G0 card is DRAFT-v0); the two-object conservative action `S_cons^G0` (6 summands) + `S_assembled` (+ `S_brane` light seam + `S_move` moving-coupling once); wall de-dup = the EXACT static-energy identity `r_B≡χ_B` (`λ_χ=4a_B ⇒ ℓ=δ`, σ match) while the FULL functionals DIFFER (inertial `Z_χ` vs Part-I dissipative `M_χ`), `g_ℓ` scope-split (cites R21, NOT merged); the drain `TWO_NONVARIATIONAL_NAMED` (Part-I `Γ_B` internal order-conversion, total-n conserved / G0 `S_drain` total-ρ sink+return — DIFFERENT balance-law objects, `S_assembled` SOURCE-FREE), equivalence UNRESOLVED, selection DEFERRED to 045 + the USER mini-gate (044 makes NO drain decision); the Decision-16 P-retirement = 4 category-clean manifests (−5=−4−1 in DRIFT not DOF, DOF 8→4 separate, drift 11→7); **`Z_χ` = a NEW DRAFT-v0 [POSTULATE] inertial-normalization action input** (dim `[-2,0,1]`=M L⁻², Class ACTION, no reduction route) ⇒ the continuous count **[40,49]→[41,50]** by 043's rule (both endpoints +1, spread 9), the committed re-count DEFERRED to 046 (may substitute the dissipative `M_χ`) — 043's [40,49] headline STANDS until 046; gravitomagnetism a PROSE pointer only (frame-dragging = the boost of the gravitoelectric flow; honest asymmetry — gravity matches GR incl GM through 4PN, EM departs Maxwell), NO gravitomag register row (047's job); dual-engine SymPy 20 / Mathematica 20 both exit 0 (byte-identical verdict 2196 B, independent DSolve/Integrate/Eigenvalues/Reduce), 43/43 guarded ablation firing at own assert, directive Codex→Grok→Codex bookend GREEN (Grok independently reproduced the 6 numeric identities), tri-review FIDELITY CLEAN + 3 can't-fail sub-conjuncts (F carrier_normalization, F target_action_dimension, E1 B_eff) FIXED ⇒ ZERO can't-fail conjuncts, deliverables fidelity-verify CLEAN (GLM-5.2 tertiary HELD for user confirm), register R93–R97 + the `Z_χ` master-parameter row, PDF 121→123pp. ⛔ **The v2 sequence's next stage WOULD have been 045 (VII-2b) — the non-variational drain/return block + BCs + force partition — but v2 STOPPED here: 045 was never built, ⛔ is not to be built, and the drain now belongs to v3's PHASE 3 (S12).** ⚠ A stage-045 PREP note exists (`research/pde_ledger_v2/notes/stage045_nonvariational_block_prep.md`) — historical: its `F_var+F_flux+F_𝔅+F_rad` force partition, return controllers and `𝔅`/mouth/collar/IR BCs remain reusable, ⛔ but its drain-placement mini-gate is **CLOSED, not an open option list**. ⭐ The committed drain is the **dynamical `Γ_B` order-conversion law** — `∂_t(χ_B n) + ∇₄·(χ_B n u + J_χ) = n Γ_B`, `Γ_B = Γ_return − Γ_drain`, `[Γ_B] = T⁻¹`: an internal order-conversion at the throat that conserves total material and converts only *order* (phase-conversion, ⛔ not suction). ⛔ The **G0 `S_drain` `ρ`-mass-sink + remote return is RULED OUT** (user, 2026-07-24) as frozen-wall-premised — *"the drain cannot be a frozen wall"* — and a static limit must be **derived** as the `ω→0` limit of the dynamical law, ⛔ never posed as an independent frozen solve (S12, `research/pde_ledger_v3/V3_STEP_PLAN.md`).

The genuinely-new synthesis, needs I–VI assembled:
- the **unified equation set** — conservative parent action PLUS explicit **non-variational** drain/return sources/controllers/BCs (NOT one functional) — the completeness floor;
- the **calibration map** (every constant tagged DERIVED / INPUT / gap / benchmark);
- a whole-system **dimensional-firewall** check;
- the permanent **registers** (open-items / no-go / calibration — the falsification record);
- the **simulation hand-off spec** (each sim-dependent quantity + its exact equation + confirming measurement);
- the **χ_Q reconciliation** (`pathA_22b≈0.712` numeric vs `pathA_33=1` exact — same name, different computations; reconcile, don't merge);
- the full irreducible count via the pathA_40 `Δr=2` codimension technique.
⚠ **Process (updated 2026-07-29/30, amended 2026-07-30):** ⛔ ~~the full new-derivation gauntlet + GLM tertiary + user gate~~ is **retired**. Per computable stage: ONE design-review pass on a fresh reviewer → dual-engine → arbiter re-run → **two mutually independent fresh review legs** (a stage's math is physics-bearing) → the **blocking physics leg**. Owned by `docs/development_pipeline.md`.

---

## 4. The honest ledger (surplus vs debt)

**Held-out / falsifiable predictions (the earned surplus, ~6–7 structural + 1 departure):** ⛔ that ~6–7 count still BANKS the three items marked below — the `1/r²` law, the attractive sign, and the stage009 `RETURN_RESIDUAL_PREDICTION` falsifier — which are **CONDITIONAL pending the S14a drain bridge, NOT earned** — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`. {#earned-surplus}
- ⛔ **CONDITIONAL pending the S14a drain bridge, NOT earned** — the gravity `1/r²` exponent + attractive
  sign. Correcting the drain to the committed dynamical `Γ_B` law severed the chain to them: they were
  derived under a Gauss **number-flux** drain. ⛔ Do not cite them as earned until the S14a bridge
  succeeds — `research/pde_ledger_v3/CHARTER.md#conditional-s14a` (*"⛔ **CONDITIONAL — neither carried nor discarded,
  pending S14a:** … the `1/r²` law, the attractive sign, and the stage009 `RETURN_RESIDUAL_PREDICTION`
  falsifier"*).
- the ℓ=2 DtN rational fingerprint `{1/9, 4/81, 1/27}`, `χ_Q=+1`, the cross-ℓ fingerprint `{1, 1/2, 1/27}`, SO(3) `λ_m=6`, and the squared-denominator signature (the `−2D₂N₀` term). (The `27` is earned separately as part of the DtN fingerprint; in `54/5=2·27/5` the `27` is earned but the `2/5` is external/calibrated — these are two distinct results, not one.)
- ⛔ **CONDITIONAL pending the S14a drain bridge, NOT earned** — the bounded monopole/dipole
  `c_s`-radiation residual `ε_ℓ/(1+ε_ℓ)`, the headline falsifier (GR/Birkhoff forbid ℓ=0/1). ⚠ This
  bullet **is** the stage009 `RETURN_RESIDUAL_PREDICTION`, severed by the same drain correction. ⛔ Do
  not cite it as earned until the S14a bridge succeeds — `research/pde_ledger_v3/CHARTER.md#conditional-s14a` (*"⛔
  **CONDITIONAL — neither carried nor discarded, pending S14a:** … the stage009
  `RETURN_RESIDUAL_PREDICTION` falsifier"*).
- ⚠ `F_e/F_g` (the hierarchy capstone) is **NOT yet held-out** — it becomes the sharpest dimensionless test only once BOTH couplings come from one throat action; presently FIT/not-tested.

**Characterized departures (first-class, never softened):**
- EM is **NOT exact Maxwell** — `NATIVE_P_NO_EMERGENT_GAUSS` (exact U(1) proven non-native);
- the **stray longitudinal DOF** — `FAIL_CAUCHY_STRAY_LONGITUDINAL` (second-class, not first-class Gauss);
- `b_T=∇×u_T` is **time-reversal EVEN** vs Maxwell's T-odd `B`;
- a real **radiating extra scalar** `h` (accelerating charge radiates scalar waves).

**Unresolved (R1) — the shared throat solve is the crux:**
- electric **sign** `R1_REQUIRED(bc_selection)`; magnetic sign inherits it;
- magnetism `r_BA=1?`, `r_cone=1?`, `q_T`, higher `v/c`, active-flux integrability;
- cross-ℓ return selector (Gate-6): the linear model does not pin `ε0/ε1`.
- **One nonlinear throat solve** is the shared R1 for gravity `{μ_R,ρ_br}` (audit R10 + R30 + R33 — *not* all six), electric `bc_selection`, and magnetism `q_T` — one interior solve collapses several knobs at once. SIM-deferred (tractability), not a knob the PDE sets. {#shared-r1-throat-solve}

**Calibrated / external (not held-out):** `G` (`GENUINE_BLOCKED`), `54/5`, `2/5`, the force-magnitude norm, the six Part-II wall-packet CALIB inputs `{μ_η, T_w, β, Vp0/ℓ_c, T_Ω, β₂}`, and the calibrated closure moments / `Γ̄₅`. (Not `λ_γ` — the *ratio* is DERIVED; what's calibrated is the *lock* `λ_γ=1`, and the free-unreduced quantity is `c_γ`.)

**Midway Knob Audit headline (Parts I–II dry-run, `midway_knob_audit.md`; post-Decision-16 −5):** irreducible total **~34–43** = universal 4 + reduction-debt 15–18 (route-ful) + postulated structure 14–20 (route-less) + force-mag 1. **Route-less liability ~15–21 ≫ held-out surplus ~6–7.** Sobering but **NOT a no-go** — a substantial portion of the debt is route-ful (reduction debt ~15–18: the throat solve + Gate-6 return closure convert CALIB→DERIVED in one stroke); post-Decision-16 the route-less liability (~15–21) is now **comparable to, no longer clearly exceeding,** the route-ful debt (~15–18), though it still robustly dominates the earned held-out surplus (~6–7). **Two parked user decisions** (C1/C2 counting convention; R35 label) pick the point in the range and must resolve before Part VII. ⛔ The "held-out surplus ~6–7" on both sides of that comparison still counts the `1/r²` law, the attractive sign and the stage009 `RETURN_RESIDUAL_PREDICTION` falsifier, which are **CONDITIONAL pending the S14a drain bridge, NOT earned** — `research/pde_ledger_v3/CHARTER.md#conditional-s14a`.

---

## 5. Ledger-v2 build status (thin — see RESUME_ROADMAP for detail)

Central equation-set rebuild at `research/pde_ledger_v2/` (branch `ledger-v2-rebuild`). Stages numbered by BUILD order (001–029), not Part order.

| Part | Sector | Status |
|---|---|---|
| 0 | Conceptual | scaffolding-only (placeholder `.tex`) |
| I | Medium | ✅ built (004–007), tri-reviewed |
| II | Gravity | ✅ built (001–002, 008–029), CLOSED |
| III | Light | ✅ DONE = stage003 (re-scoped 2026-07-22, surviving-solution rule) |
| IV | Charge | ✅ COMPLETE — in-ledger (030–033, 2026-07-22) |
| V | Magnetism | ✅ COMPLETE — split RATIFIED (034–039); stages 034 (V-1) + 035 (V-2) + 036 (V-3) + 037 (V-4, crux) + 038 (V-5, SEALED landing) + 039 (V-6, `B_TIME_REVERSAL_EVEN` departure) DONE + committed `109070da`/`b55a7a65`/`df045a74`/`c8780f00`/`177d25d7`/`63f28258` |
| VI | Knit | ✅ COMPLETE (split RATIFIED 3 stages 040/041/042, order 041→040→042; 040+041+042 DONE `1701c921`/`c663d4a3`/`0961b27c` — Part VI COMPLETE) |
| VII | Integration | ⛔ SUPERSEDED 2026-07-31 (v2 history, ⛔ not an instruction) — 043,044 ✅ (2/7); 045–049 never built, ⛔ not to be built; front = v3 (`docs/model_map.md#current-front`) |

**Build order (v2 — ⛔ SUPERSEDED 2026-07-31, history, ⛔ not an instruction; the front is v3, `docs/model_map.md#current-front`):** III → IV → V → VI → VII. **How far it got:** ✅ Parts I–VI DONE (**Part IV charge COMPLETE 2026-07-22, stages 030–033**: 030 electric-scalar closure / 031 puncture-deflection mechanism EARNED / 032 `R1_REQUIRED(bc_selection)` / 033 `NATIVE_P_NO_EMERGENT_GAUSS` departure) → **Part V (magnetism) ✅ COMPLETE 2026-07-23**: 6-stage split `part5_magnetism_atomic_split.md` RATIFIED; stages 034 (V-1, `TRANSVERSE_MOVE_ACTION_ROW`) + 035 (V-2, `CONVECTION_LIKE_CONDITIONAL`) + 036 (V-3, `MAXWELL_DARWIN_REFERENCE`) + 037 (V-4, crux, `BOOST_STRUCTURAL_RELATION_HOLDS`) + 038 (V-5, SEALED landing, `R1_REQUIRED(electric_bc_selection)`) + 039 (V-6, `B_TIME_REVERSAL_EVEN` departure) DONE + committed `109070da`/`b55a7a65`/`df045a74`/`c8780f00`/`177d25d7`/`63f28258` → **Part VI (the knit) ✅ COMPLETE 2026-07-23**: split RATIFIED (3 stages, build order 041→040→042); **stage 041 (VI-2, NG5) ✅ DONE + committed `c663d4a3`** (`SECOND_MEDIUM_DRIFT(active_irreducible={rho_B0,chi_c,C_hu})`, labelling-level one-medium closure); **stage 040 (VI-1, cone-lock re-adjudication) ✅ DONE + committed `1701c921`** (`CONE_LOCK_CALIBRATED`, no committed cone lock — CALIBRATED/UNCOMMITTED, `Δr=2`); **stage 042 (VI-3, charge-coupled scalar) ✅ DONE + committed `0961b27c`** (`SCALAR_DEPARTURE_MAPPED_MAGNITUDE_SIM_GATED`, canonical count 41→42) = the LAST Part VI stage → **✅ Part VI COMPLETE (040/041/042)** → **Part VII (integration) 🔄 IN PROGRESS**: stage 043 (VII-1, count-as-range) ✅ DONE + committed `fda05f46` (continuous [40,49] + separate discrete 11) → **stage 044 (VII-2a, parent-action spine) ✅ DONE + committed `087565b0`** (`PARENT_ACTION_ASSEMBLED_AT_COMPLETENESS_FLOOR`, completeness-floor only, G0 card DRAFT-v0; two-object `S_cons^G0` + `S_assembled`, wall de-dup `r_B≡χ_B` with full functionals differing [`Z_χ` vs `M_χ`], drain `TWO_NONVARIATIONAL_NAMED` selection deferred to 045 + the USER mini-gate; `Z_χ` new DRAFT-v0 input ⇒ count [40,49]→[41,50], committed re-count deferred to 046, register R93–R97) = 2/7; ⛔ **STOPPED HERE — 045 (VII-2b, non-variational drain/return block) was never built and ⛔ is not to be built; the drain moved to v3's S12.** Each executable stage = the 6-artifact unit (note · TeX card · SymPy audit · independent Mathematica audit · source map · register entry), dual-engine both exit 0, ⚠ **and — for stages 045–049, per the 2026-07-29/30 decision as amended 2026-07-30 — ONE design-review pass on a fresh reviewer plus TWO mutually independent fresh review legs (fidelity + per-tooth ablation; a stage's math is physics-bearing), with the physics leg blocking; the per-stage Codex→Grok→Codex bookend, the fixed three-leg tri-review and the two automatic user gates are retired** (043/044 above were built under the older three-leg form, which is why their records say "tri-review"). Full detail: `research/pde_ledger_v2/notes/RESUME_ROADMAP.md`.

### 5.1 Ledger completion manifest — exactly what math folds into each remaining Part, and where it lives

*Verified to resolve on disk. **Already done:** Parts I+II+III = ledger stages 001–029 (source = the §3.1/§3.2 pathA reports + PN corpus; Part III = stage003 alone, the surviving light sector, re-scoped 2026-07-22). This manifest covers the REMAINING Parts IV–VII (the Part III entry below is retained as DONE for reference).*

**Reshape tiers (the per-gate cost of bringing a script into the ledger's print-only/assert-zero/independent-`.wl` contract):**
- **FULL** — the `pathA_*` tools carry an `argparse --compare` + JSON/YAML payload harness and a payload-mirror `.wl`; folding = strip the harness → print-only/assert-zero/exit-nonzero, AND re-author the `.wl` as a genuinely independent route.
- **LIGHT** — the `software/em_charge_attribute/` EM builds are already assert-heavy (only minor harness); folding = wrap into the 6-artifact stage form + confirm the `.wl` is an independent route.

**Part III — Light** ✅ **DONE = stage003** (re-scoped 2026-07-22, surviving-solution rule). The surviving light sector is the single built stage `ledger_stage003` (`FAIL_CAUCHY_STRAY_LONGITUDINAL`, earned 2 transverse photons at `c_γ²=μ_R/ρ_br`, `μ_R` postulated) — `research/pde_ledger_v2/scripts/…_sympy_audit.py` · `…/mathematica/…_audit.wl`, split `part3_light_atomic_split.md`.
- The `pathA_35` gateL couple-stress no-go (`FAIL_COUPLE_STRESS_NOGO`, retired-`P` post-mortem) is **NOT a ledger stage** → failures-paper backlog Exclusion 1. `c_γ²=μ_R/ρ_br` is the `u_T`/`c_γ` foundation Part V reuses.

**Part IV — Charge** ✅ **DONE** (4-stage split 030–033, 2026-07-22; `part4_charge_atomic_split.md`). Below = what was folded.
- Source math: `software/em_charge_attribute/puncture_deflection_electric_sign_result.md`, `…/g0_closure_card_v0.md`, `…/reports/native_p_constraint_gate.md`
- Scripts (LIGHT reshape): `software/em_charge_attribute/puncture_deflection_electric_sign_check.py` · `…_check.wl` (+ `…_independent_recompute.py`); `…/g0_closure_card_v0_checks.py` · `…_checks.wl`; `…/native_p_gate_sympy.py` · `…/native_p_gate_dual.wl`
- Owed: fold the `(u_L,h)` block + `ξ_w=ℓh` + h-mediated `1/R²`; carry `R1_REQUIRED(bc_selection)` (sign unresolved) + the `NATIVE_P_NO_EMERGENT_GAUSS` departure; **G0-vs-Part-I de-dup is deferred to Part VII** (reconcile, not additive-merge).

**Part V — Magnetism** → author `…/part5_magnetism_atomic_split.md` → ~4–6 stages.
- Source math: `software/em_charge_attribute/magnetism_moving_throat_result.md`
- Scripts (LIGHT reshape): `software/em_charge_attribute/magnetism_moving_throat_check.py` · `…_check.wl`
- Owed: fold the `S_{T+move}` transverse-vector row + native `J_T=q_T sηV`; carry `R1_REQUIRED(electric_bc_selection)` + its 3 co-blockers + the `b_T` T-even departure; reuse Part III's `u_T`/`c_γ`. (Blueprint's `pathA_39`/`j∝sV` scope is superseded — do NOT fold it.)

**Part VI — Knit** → `…/part6_knit_atomic_split.md` ✅ RATIFIED → **3 stages** (040/041/042), build order 041→040→042.
- Source math: `software/stage1_solver/reports/pathA_40_cone_lock.md`, `…/pathA_41_ng5_second_medium_drift.md`, `…/pathA_42_charge_coupled_scalar.md`
- Scripts (FULL reshape): `software/stage1_solver/tools/pathA_40_cone_lock_sympy.py` · `…/pathA_40_cone_lock.wl`; `…/pathA_41_ng5_second_medium_drift_sympy.py` · `…/pathA_41_ng5_second_medium_drift.wl`; `…/pathA_42_charge_coupled_scalar_sympy.py` · `…/pathA_42_charge_coupled_scalar.wl`
- Owed: **RE-ADJUDICATE** the cone-lock — `pathA_40`'s calibrated `λ_γ=1`/`c_E=c_γ` are no longer established by the G0 card / magnetism build (no committed lock); carry the NG5 `{ρ_B0,χ_c,C_hu}` reduction-incompleteness + the `pathA_42` `SCALAR_DEPARTURE_MAPPED_MAGNITUDE_SIM_GATED` sim-gated risk.

**Part VII — Integration** → author `…/part7_integration_atomic_split.md` → ~5–8 GENUINELY-NEW stages (synthesis; ⛔ ~~full new-derivation gauntlet + GLM tertiary~~ retired 2026-07-29/30 — see §3.7 and `docs/development_pipeline.md`).
- Source math: assembles Parts I–VI (no single prior script). χ_Q reconciliation sources: `software/stage1_solver/reports/pathA_22b_minimal_combination_xi.md` (numeric ≈0.712) vs `software/stage1_solver/tools/pathA_33_quadrupole_normalization_sympy.py` · `…/pathA_33_quadrupole_normalization.wl` (exact =1).
- Owed: author the unified equation set (conservative action + explicit non-variational drain/return sources/BCs), the calibration map, the whole-system dimensional firewall, the open-items/no-go/calibration registers, the simulation hand-off spec, the χ_Q reconciliation, and the full irreducible count via the `pathA_40` `Δr=2` codimension technique.

---

## 6. Known staleness / to-reconcile (don't be misled)

- **Decision 16 (P-retirement) has LANDED (2026-07-21)** — operative and folded into the ledger (stage006/007 audit scripts + `parameter_register.md`): a definite **−5** route-less reduction (operative DOF=4, `POST_D16_DRIFT(7)`, stage006 `DRIFT(5)`; `λ_Pu`+`α_aniso` retired; the historical freeze-as-run "11"/DOF=8 record STANDS immutable). The `χ_B=|P_∥|²` route (c) is obsolete-as-carried unless a new T0 freeze is authorized (a live, high-risk future gate whose collapse would clear ~half of the postulated-structure liability). Full decision + failed-payoff evidence: `software/stage1_solver/decisions/16_retire_brane_polar_field.md`; retired-`P` post-mortems → `research/pde_ledger_v2/notes/ledger_exclusions_failures_paper_backlog.md`.
- **Blueprint Parts IV/V scope is stale by design** — scoped on `pathA_38`/`pathA_39` before the EM reconsideration; `pathA_39` rests on the barred `j∝sV`. Re-scope onto the puncture-deflection + moving-throat builds.
- **Blueprint Part-VI cone-lock framing is stale** — it records pathA_40 as a settled `CONE_LOCK_CALIBRATED`; the newer builds don't establish the locks → it's a *to-re-adjudicate*.
- **χ_Q reconciliation** (`0.712` vs `1`) — live Part-VII debt.
- **G0 card is DRAFT v0** — un-reconciled with Part I; de-dup at Part VII, not additive-merge.
- **The old 253-stage `research/pde_ledger/`** is a SUPERSEDED quarry — cite the v2 Part-II stages + pathA reports as the earned source, not it.


---

## 7. Glossary

- **Primitive constants** — the medium's ~4 declared-universal inputs: `ħ`, `m_GNLS`, `K`, `ρ0`. **`m_GNLS`** is the condensate boson mass — a *declared universal constant*, NOT emergent; do **not** confuse it with **`m_defect`** (a particle's mass), which is a GAP (`INFLOW_MASS_SOURCE_MISSING`, not derived — only a dimensional bridge `m∼α_J ħJ/c_γ²` exists).
- **Defect / throat / puncture** — a particle: a topological puncture of the brane into `±w`. Never "dent".
- **Brane** — the ordered (`χ_B=1`), shear-supporting phase; our 3D space, a domain wall at `w=0`. **Bulk** — the same medium de-structured (`χ_B=0`), shear-free.
- **±w** — the two sides the throat punctures into; the charge **sign** is this orientation (Z₂, not additive).
- **Drain** — a throat removing number-flux; gravity is the flow between drains.
- **Cone / speed** — `c_s` (density/gravity-change), `c_γ` (light, shared with magnetism), `c_E` (electric, no committed lock). `λ_γ=c_γ/c_s`.
- **DtN** — Dirichlet-to-Neumann map; the exterior-wave operator whose rational coefficients are the earned fingerprint. **χ_Q** — the outgoing-wave sign (`+1`).
- **R1_REQUIRED(x)** — an honest *unresolved* landing: the result needs the named closure `x` (usually the sim-deferred nonlinear throat solve). Not a failure, not a fudge — a scoped open item.
- **Departure** — a characterized, first-class break from the reference theory (GR or Maxwell); welcome, not a bug.
- **Atomic split** — the plan that decomposes a Part into individual buildable **stages**, approved at the per-Part gate before building.
- **Stage / 6-artifact unit** — the smallest verifiable derivation: note + TeX card + SymPy audit + independent Mathematica audit + source map + register entry.
- **Knit (Part VI)** — the consistency check that the four sectors are ONE medium (shared cones `pathA_40`, no smuggled second substance `pathA_41`, consistent scalar `pathA_42`).
- **Integration (Part VII)** — the unified equation set + calibration map + registers + sim hand-off spec — the literal deliverable.
- **Cone-lock** — a calibrated equality between two cones (`λ_γ=1`, `c_E=c_γ`); not derived, must be re-adjudicated.
- **GENUINE_BLOCKED** — a magnitude (e.g. `G`) that is a genuine external anchor, not derivable at this level.
- **Review leg** (formerly "tri-review") — an **arbiter re-run** by the orchestrator plus a **fresh agent** doing both the term-by-term fidelity read and the per-tooth ablation, with the ablation target list owned by the orchestrator. ⭐ **On a physics-bearing artifact (a stage's math, a derivation) this runs on TWO mutually independent fresh agents**; prose, process and tooling get one (amended 2026-07-30). ⚠ Collapsed from three fixed legs 2026-07-29/30; what is kept is *freshness*, *independence*, and the orchestrator-owned target list — not a model sequence. Older stage notes say "tri-review" — that is the historical three-leg form. Owned by `docs/development_pipeline.md` Phase 4.
- **The G0 card** — the shared minimal closure card (`g0_closure_card_v0.md`); a DRAFT v0 postulated closure the EM builds reduce from.